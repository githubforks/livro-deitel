/*
 * Modifique o programa no Exercício 23.9 para adicionar uma nova bola toda vez
 * que o usuário clicar no mouse. Ofereça um mínimo de 20 bolas. Escolha a cor
 * para cada nova bola aleatoriamente.
 */

package ch23.Exer23_10;

public class Exer23_10 {

}
