/*
 * Elabore um programa que faça uma bola azul rebater em um JPanel. A bola deve
 * começar a se mover com um evento mousePressed. Quando a bola atingir a borda
 * do JPanel, ela deve rebater fora da borda e continuar na direção oposta. A
 * bola deve ser atualizada com uma interface Runnable.
 */

package ch23.Exer23_09;

public class Exer23_09 {

}
