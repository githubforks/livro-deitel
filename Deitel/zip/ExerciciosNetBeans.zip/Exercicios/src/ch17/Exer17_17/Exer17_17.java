/*
 * Escreva um programa baseado no programa das figuras 17.17 e 17.18 que insira
 * uma linha de texto, divida (tokenize) a frase em palavras separadas (talvez
 * você queira utilizar a classe StreamTokenizer do pacote java.io), insira as
 * palavras em uma árvore de pesquisa binária e imprima os percursos na
 * pré-ordem, na ordem e na pós-ordem da árvore.
 */

package ch17.Exer17_17;

public class Exer17_17 {

}
