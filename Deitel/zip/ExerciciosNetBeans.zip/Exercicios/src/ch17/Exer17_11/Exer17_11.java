/*
 * Escreva um programa que utiliza uma pilha para determinar se uma string é um
 * palíndromo (isto é, a string é escrita identicamente de trás para frente). O
 * programa deve ignorar espaços e pontuação.
 */

package ch17.Exer17_11;

public class Exer17_11 {

}
