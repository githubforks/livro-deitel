/*
 * Escreva um programa que insere 25 inteiros aleatórios de 0 a 100 na ordem em
 * um objeto lista vinculada. O programa deve calcular a soma dos elementos e a
 * média de ponto flutuante dos elementos.
 */

package ch17.Exer17_08;

public class Exer17_08 {

}
