/*
 * Escreva um programa que concatena dois objetos de lista vinculada de
 * caracteres. A classe ListConcatenate deve incluir um métdodo concatenate que
 * aceita referências tanto para objetos de lista como para argumentos e
 * concatena a segunda lista com a primeira lista.
 */

package ch17.Exer17_06;

public class Exer17_06 {

}
