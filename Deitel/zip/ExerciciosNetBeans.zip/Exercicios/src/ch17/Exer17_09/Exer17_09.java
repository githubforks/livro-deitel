/*
 * Escreva um programa que cria um objeto lista vinculada de 10 caracteres,
 * então cria um segundo objeto lista contendo uma cópia da primeira lista, mas
 * na ordem inversa.
 */

package ch17.Exer17_09;

public class Exer17_09 {

}
