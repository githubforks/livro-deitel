/*
 * Modifique as figuras 17.17 e 17.18 para permitir que a árvore binária
 * contenha duplicatas.
 */

package ch17.Exer17_16;

public class Exer17_16 {

}
