/*
 * (Pesquisa de árvore binária) Escreva o método binaryTreeSearch, que tenta
 * localizar um valor especificado em um objeto árvore pesquisa binária. O
 * método deve aceitar como um argumento uma chave de pesquisa a ser localizada.
 * Se o nó contendo a chave de pesquisa for localizado, o método deve retornar
 * uma referencia a esse nó; caso contrário, ele deve retornar uma referência
 * nula.
 */

package ch17.Exer17_23;

public class Exer17_23 {

}
