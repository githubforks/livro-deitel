/*
 * Escreva um programa que insere uma linha de texto e utiliza um objeto pilha
 * para imprimir as palavras da linha na ordem inversa.
 */

package ch17.Exer17_10;

public class Exer17_10 {

}
