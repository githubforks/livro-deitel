/*
 * Modifique o programa avaliador de pos-fixo do Excrcício 17.13 de modo que de
 * possa processar os operandos inteiros maiores que 9.
 */

package ch17.Exer17_14;

public class Exer17_14 {

}
