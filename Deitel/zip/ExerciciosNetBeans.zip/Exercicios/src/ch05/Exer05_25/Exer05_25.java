/*
 * Modifique o aplicativo que você escreveu no Exercício 5.24 para ler um número
 * ímpar no intervalo 1 a 19 para especificar o número de linhas no losango. Seu
 * programa então deve exibir um losango do tamanho apropriado.
 */

package ch05.Exer05_25;

public class Exer05_25
{
	public static void main(String[] args)
	{
		
	}
}
