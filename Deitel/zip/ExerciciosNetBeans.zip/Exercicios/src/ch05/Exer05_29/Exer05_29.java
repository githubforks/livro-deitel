/*
 * (A canção The Twelve Days of Christmas) Escreva um aplicativo que utiliza instruções de
 * repetição switch para imprimir a canção The Twelve Days of Christmas. Uma instrução switch
 * deve ser utilizada para imprimir o dia (isto é, 'First', 'Second' etc.) Uma instrução
 * switch separada deve ser utilizada para imprimir o restante de cada verso. Visite o site da
 * Web www.12days.com/library/carols/12daysofxmas.htm para obter a letra completa da canção.
 * 
 * 						The Twelve days of Christmas
 *
 *						On the first day of Christmas
 *						  my true love sent to me:
 * 						 A Partridge in a Pear Tree
 * 
 * 						On the second day of Christmas
 * 						   my true love sent to me:
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 *
 * 						On the third day of Christmas
 *						   my true love sent to me:
 * 						     Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 *
 * 						On the fourth day of Christmas
 * 						   my true love sent to me:
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the fifth day of Christmas
 * 						   my true love sent to me:
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the sixth day of Christmas
 * 						   my true love sent to me:
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the seventh day of Christmas
 * 						   my true love sent to me:
 * 							Seven Swans a Swimming
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 							  and a Partridge in a Pear Tree
 * 
 * 						On the eighth day of Christmas
 * 							my true love sent to me:
 * 							 Eight Maids a Milking
 * 							 Seven Swans a Swimming
 * 							   Six Geese a Laying
 * 							   Five Golden Rings
 * 							   Four Calling Birds
 * 							   Three French Hens
 * 							   Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the ninth day of Christmas
 * 							my true love sent to me:
 * 							  Nine Ladies Dancing
 * 							  Eight Maids a Milking
 * 							  Seven Swans a Swimming
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the tenth day of Christmas
 * 							my true love sent to me:
 * 							  Ten Lords a Leaping
 * 							  Nine Ladies Dancing
 * 							  Eight Maids a Milking
 * 							  Seven Swans a Swimming
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the eleventh day of Christmas
 * 							my true love sent to me:
 * 							  Eleven Pipers Piping
 * 							  Ten Lords a Leaping
 * 							  Nine Ladies Dancing
 * 							  Eight Maids a Milking
 * 							  Seven Swans a Swimming
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 * 
 * 						On the twelfth day of Christmas
 * 							my true love sent to me:
 * 							  12 Drummers Drumming
 * 							  Eleven Pipers Piping
 * 							  Ten Lords a Leaping
 * 							  Nine Ladies Dancing
 * 							  Eight Maids a Milking
 * 							  Seven Swans a Swimming
 * 							  Six Geese a Laying
 * 							  Five Golden Rings
 * 							  Four Calling Birds
 * 							  Three French Hens
 * 							  Two Turtle Doves
 * 						and a Partridge in a Pear Tree
 */

package ch05.Exer05_29;

public class Exer05_29
{
	public static void main(String[] args)
	{
		
	}
}
