/*
 * Escreva um aplicativo que calcule o produto dos inteiros ímpares de 1 a 15.
 */

package ch05.Exer05_12;

public class Exer05_12 {
    public static void main ( String args[] )
    {
    	
    }
}
