/*
 * Uma aplicação interessante de computadores é exibir gráficos de barras.
 * Escreva um aplicativo que leia cinco números entre 1 e 30. Para cada número
 * que é lido, seu programa deve exibir o mesmo número de asteriscos adjacentes.
 * Por exemplo, se seu programa lê o número 7, ele deve exibir *******.
 */

package ch05.Exer05_16;

public class Exer05_16
{
	public static void main(String[] args)
	{
		
	}
}
