/*
 * Escreva um programa que utilize o caractere de conversão g para gerar a saída
 * do valor 9876,12345. Imprima o valor com precisões no intervalo entre 1 e 9.
 */

package ch28.Exer28_13;

public class Exer28_13 {

}
