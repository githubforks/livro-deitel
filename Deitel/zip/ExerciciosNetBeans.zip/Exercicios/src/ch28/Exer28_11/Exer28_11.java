/*
 * (Convertendo temperaturas Fahrenheit em Celsius) Escreva um programa que
 * converta valores inteiros de temperatura em Fahrenheit entre 0 e 212 graus
 * para temperaturas em Celsius de pontos flutuante com três digitos de
 * precisão. Utilize a Fórmula
 *      celsius = 5.0 / 9.0 * ( fahrenheit - 32 );
 * para realizar o cálculo. A saída deve ser impressa em duas colunas à linha da
 * direita de 10 caracteres cada e as temperaturas Celsius devem ser precedidas
 * por um sinal para valores positivos e negativos.
 */

package ch28.Exer28_11;

public class Exer28_11 {

}
