/*
 * Escreva um programa para testar todas as seqüências de escape na Figura
 * 28.23. Para as seqüências de escape que movem o cursor, imprima um caractere
 * antes e um depois da seqüência de escape de modo que fique claro o local para
 * onde o cursor se moveu.
 */

package ch28.Exer28_12;

public class Exer28_12 {

}
