/*
 * Escreva um programa que lê uma serie de primeiros nomes e os armazena em uma
 * LinkedList. Não armazene nomes duplicados. Permita que o usuário procure um
 * primeiro nome.
 */

package ch19.Exer19_13;

public class Exer19_13 {

}
