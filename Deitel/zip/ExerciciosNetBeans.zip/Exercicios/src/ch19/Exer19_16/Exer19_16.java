/*
 * Escreva um programa que determina e imprime o número de palavras duplicadas
 * em uma frase. Trate da mesma maneira letras minúsculas e letras maiúsculos.
 * Ignore a pontuação.
 */

package ch19.Exer19_16;

public class Exer19_16 {

}
