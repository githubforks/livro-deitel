/*
 * A saída da Figura 19.17 (PriorityQueueTest) mostra que PriorityQueue ordena
 * elementos Double em ordem crescente. Reescreva a Figura 19.17 de modo que ela
 * ordene os elementos Double em ordem decrescente (isto é, 9.8 deve ser o
 * elemento de maior prioridade em vez de 3.2).
 */

package ch19.Exer19_21;


public class Exer19_21 {

}
