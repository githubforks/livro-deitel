/*
 * Escreva um programa que aceita a entrada de um número inteiro do usuário e
 * determina se o número é primo. Se o número não for primo exiba os únicos
 * fatores primos do número. Lembre-se de que os fatores de um número primo são
 * somente 1 e o próprio numero primo. Cada número que não é primo tem uma
 * fatoração em primos única. Por exemplo, considere o numero 54. Os falares
 * primos de 54 são 2, 3, 3 e 3. Quando os valores são multiplicados, o
 * resultado é 54. Para o numero 54, a saida dos fatores primos deve ser 2 e 3.
 * Utilize Sets como parte de sua solução.
 */

package ch19.Exer19_19;

public class Exer19_19 {

}
