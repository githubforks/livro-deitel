/*
 * Escreva um código Java para começar a implementar o projeto da classe
 * Transaction especificada nas figuras 10.21 e 10.22. Certifique-se de
 * incluir atributos de tipo por referência private como base nas associações da
 * classe Transaction. Também se certifique de incluir os métodos get public que
 * fornecem acesso a qualquer desses atributos private que as subclasses exigem
 * para realizar suas tarefas.
 */

package ch10.Exer10_03;

public abstract class Transaction {

}
