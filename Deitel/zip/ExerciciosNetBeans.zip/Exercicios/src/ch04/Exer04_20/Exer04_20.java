/*
 * Desenvolva um aplicativo Java que determine o salário bruto de cada um dos três empregados.
 * A empresa paga 'hora normal' pelas primeiras 40 horas trabalhadas por cada funcionário
 * e 50% a mais para todas as horas trabalhadas além de 40 horas. Você recebe uma lista dos
 * empregados da empresa, o número de horas trabalhadas por empregado na última semana e o
 * salário-hora de cada empregado. Seu programa deve aceitar a entrada dessas informações para
 * cada empregado e então determinar e exibir o salário bruto do empregado. Utilize a classe
 * Scanner para inserir os dados.
 */

package ch04.Exer04_20;

public class Exer04_20
{
	public static void main(String[] args)
	{
		
	}
}