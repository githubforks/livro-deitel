/*
 * Os motoristas se preocupam com a quilometragem de seus automóveis.
 * Um motorista monitorou vários tanques cheios de gasolina
 * registrando a quilometragem dirigida e a quantidade de combustível
 * em litros utilizados para cada tanque cheio. Desenvolva um
 * aplicativo Java que receba como entrada os quilômetros dirigidos
 * e os litros de gasolina consumidos (ambos como inteiros) para cada
 * tanque cheio. O programa deve calcular e exibir o consumo em
 * quilômetros/litro para cada tanque cheio e imprimir a quilometragem
 * combinada e a soma total de litros de combustível consumidos até
 * esse ponto. Todos os cálculos de média devem produzir resultados
 * de pronto flutuante. Utilize a classe Scanner e repetição controlada
 * por sentinela para obter os dados do usuário.
 */

package ch04.Exer04_17;

public class Exer04_17
{
	public static void main(String[] args)
	{
		
	}
}
