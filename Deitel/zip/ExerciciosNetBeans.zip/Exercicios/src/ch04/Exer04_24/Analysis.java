/*
 * Modifique o programa na Figura 4.12 para validar suas entradas. Para qualquer entrada, se
 * o valor entrado for diferente de 1 ou 2, continue o loop até o usuário inserir um valor
 * correto.
 */

package ch04.Exer04_24;

public class Analysis 
{

}