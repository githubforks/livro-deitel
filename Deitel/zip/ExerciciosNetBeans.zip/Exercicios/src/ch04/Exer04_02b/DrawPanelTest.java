package ch04.Exer04_02b;

public class DrawPanelTest
{
	public static void main( String args[] )
	{
		
	}
}