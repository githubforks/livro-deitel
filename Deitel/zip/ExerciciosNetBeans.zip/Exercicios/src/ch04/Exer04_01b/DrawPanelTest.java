package ch04.Exer04_01b;

public class DrawPanelTest
{
	public static void main( String args[] )
	{
		
	}
}