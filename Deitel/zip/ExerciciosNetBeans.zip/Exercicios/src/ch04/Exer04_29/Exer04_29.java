/*
 * Escreva um aplicativo que solicite ao usuário inserir o tamanho do lado de um quadrado
 * e então exiba um quadrado vazio desse tamanho com asteriscos. Seu programa deve trabalhar
 * com quadrados de todos os comprimentos de lado possíveis entre 1 e 20.
 */

package ch04.Exer04_29;

public class Exer04_29
{
	public static void main(String[] args)
	{
		
	}
}
