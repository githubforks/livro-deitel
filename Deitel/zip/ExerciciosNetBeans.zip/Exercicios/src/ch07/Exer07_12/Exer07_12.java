/*
 * (Eliminação de duplicatas) Utilize um array unidimensional para resolver o
 * seguinte problema: Escreva um aplicativo que insere cinco números, cada um
 * dos quais está entre 10 e 100, inclusive. Enquanto cada número é lido, exibe
 * somente se le não tiver duplicata de um número já lido. Cuide de tratar o 'pior
 * caso', em que todos os 20 números são diferentes. Utilize o menor array possível
 * para resolver esse problema. Exiba o conjunto completo de valores únicos inseridos
 * depois que o usuário inserir cada valor novo.
 */

package ch07.Exer07_12;

public class Exer07_12 {

}
