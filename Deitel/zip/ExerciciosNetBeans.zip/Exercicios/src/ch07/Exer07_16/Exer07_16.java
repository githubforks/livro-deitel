/*
 * Escreva um aplicativo que utiliza uma instrução for aprimorada para somar os
 * valores double passados pelos argumentos de linha de comando. [Dica: Utilize
 * o método static parseDouble da classe Double para converter uma String em um
 * valor double.]
 */

package ch07.Exer07_16;

public class Exer07_16 {

}
