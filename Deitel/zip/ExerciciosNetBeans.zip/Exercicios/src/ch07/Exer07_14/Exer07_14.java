/*
 * Escreva um aplicativo que calcule o produto de uma série de inteiros que são
 * passados para o método product utilizando uma lista de argumentos de comprimento
 * variável. Teste seu método com variáveis chamadas, cada uma com um número
 * diferente de argumentos.
 */

package ch07.Exer07_14;

public class Exer07_14 {

}
