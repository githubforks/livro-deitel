/*
 * Modifique o aplicativo da seção 6.10 para fornecer uma GUI que permite ao
 * usuário clicar em um JButton para lançar os dados. O aplicativo também deve
 * exibir quatro JLabels e quatro JTextFields, com um JLabels para cada
 * JTextField. Os JTextFields devem ser utilizados para exibir os valores de
 * cada dado e a soma dos dados depois de cada lançamento. O ponto deve ser
 * exibido no quarto JTextField quando o usuário não ganhar ou perder no
 * primeiro lançamento e deve continuar a ser exibido até que o jogo seja
 * perdido.
 */

package ch11.Exer11_17;

public class Exer11_17 {

}
