/*
 * Crie a seguinte GUI. Você não precisa fornecer funcionalidades.
 */

package ch11.Exer11_08;

public class Exer11_08 {

}
