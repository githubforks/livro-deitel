/*
 * Aprimore o aplicativo de conversão de temperatura do exercício 11.12 adicionando
 * a escala de temperatura Kelvin. O aplicativo também deve permitir ao usuário
 * fazer conversões entre quaisquer duas escalas. Utilize a seguinte fórmula para
 * a conversão entre Kelvin e Celcius (além da fórmula no Exercício 11.12):
 *      Kelvin = Celcius + 273.15
 */

package ch11.Exer11_13;

public class Exer11_13 {

}
