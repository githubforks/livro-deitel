/*
 * Crie a seguinte GUI. Você não precisa fornecer funcionalidades.
 */

package ch11.Exer11_11;

public class Exer11_11 {

}
