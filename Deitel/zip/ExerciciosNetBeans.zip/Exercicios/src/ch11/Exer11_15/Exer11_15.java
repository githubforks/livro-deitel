/*
 * Escreva um aplicativo que joga 'adivinhe o número', como asseguir: Seu
 * aplicativo escolhe o número a ser adivinhado selecionando um inteiro
 * aleatóriamente no intervalo 1-1000. O aplicativo então exibe o seguinte em
 * um rótulo:
 *      Tenho um número entre 1 e 1000. Você pode adivinhar o número?
 *      Digite sua primeira tentativa.
 * Um JTextField deve ser utilizado para entrar a suposição. Conforme cada
 * suposição é inserida, a cor de fundo deve mudar para vermelho ou azul.
 * Vermelho indica que o usuário está ficando 'mais quente' e o azul indica que
 * o usuário está ficando 'mais frio. Um JLabel deve exibir "Muito alto" ou
 * "Muito alto" para ajudar o usuário zerar na resposta correta. Quando o
 * usuário obtiver a resposta correta, "Correct!" deve ser exibido e o JTextField
 * utilizado para a entrada deve ser alterado para se tornar não editável. Um
 * JButtom deve ser fornecido para permitir ao usuário jogar de novo. Quando o
 * JButtom for clicado, um novo número aleatório deverá ser gerado e a entrada
 * JTextFiel deverá ser alterada para o estado editável.
 */

package ch11.Exer11_15;

public class Exer11_15 {

}
