/*
 * Escreva um aplicativo de conversão de temperatura que converte Fahrenheit para
 * Celcius. A temperatura em Fahrenheit deve ser inserida pelo teclado (via
 * JTextField). Um JLabel deve ser utilizado para exibir a temperatura convertida.
 * Utilize a seguinte fórmula para a conversão Celcius =  9/5 x (fahrenheit = 32)
 */

package ch11.Exer11_12;

public class Exer11_12 {

}
