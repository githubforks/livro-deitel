/*
 * Escreva um aplivativo que exibe uma caixa, uma oval, uma seta e um losango
 * utilizando asteriscos (*), como segue:
 * 			*********     ***      *       *
 *			*       *   *     *   ***     * *
 *			*       *   *     *  *****   *   *
 *			*       *   *     *    *    *     *
 *			*       *   *     *    *   *       *
 *			*       *   *     *    *    *     *
 *			*       *   *     *    *     *   *
 *			*       *   *     *    *      * *
 *			*********     ***      *       *
 */

package ch02.Exer02_18;

public class Exer02_18
{
    public static void main(String[] args)
	{
    	
    }
}
