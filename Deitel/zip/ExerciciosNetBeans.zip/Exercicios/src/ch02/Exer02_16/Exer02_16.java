/*
 * Escreva um aplicativo que solicita ao usuário inserir dois inteiros, obtém do
 * usuário esses números e exibe o número maior seguido pelas palavras
 * "is larger". Se os números forem iguais, imprima a mensagem "These numbers
 * are equal". Utilize as técnicas mostrada na figura 2.15.
 */

package ch02.Exer02_16;

public class Exer02_16
{
	public static void main(String[] args)
	{
		
	}
}
