/*
 * Escreva um aplicativo que insere três inteiros digitados pelo usuário e exibe
 * a soma, a média, o produto e os números menores e maiores. Utilize as
 * técnicas mostradas na Figura 2.15. [Nota: O cálculo da média nesse exercício
 * deve resultar em uma representação de inteiro da média. Assim, se a soma dos
 * valores for 7, a média deverá ser 2 e não 2,3333...]
 */

package ch02.Exer02_17;

public class Exer02_17
{
	public static void main(String[] args)
	{
		
	}
}