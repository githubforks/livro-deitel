/*
 * Escreva um aplicativo que leia cinco inteiros, determina e imprime o maior e
 * o menor inteiro no grupo. Utilize somente as técnicas de programação que você
 * aprendeu neste capítulo.
 */

package ch02.Exer02_24;

public class Exer02_24
{
	public static void main(String[] args)
	{
		
	}
}
