/*
 * 	Utilizando as instruções que você escreveu no Exercício 2.5, escreva um
 * programa completo que calcule e imprima o produto de três inteiros.
 */

package ch02.Exer02_06;

public class Product
{
	public static void main(String[] args)
	{

	}
}