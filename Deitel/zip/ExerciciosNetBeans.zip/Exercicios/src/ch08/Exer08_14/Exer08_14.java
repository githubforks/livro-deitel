/*
 * (Classe Retângulo aprimorada) Crie uma classe Rectangle mais sofisticada do
 * que aquela que você criou no Exercício 8.4. Essa classe armazena somente as
 * coordenadas cartesianas dos quatro vértices do retângulo. O construtor chama
 * um método set que aceita quatro conjuntos de coordenadas e verifica se cada
 * um deles está no primeiro quadrante sem coordenadas x ou y individualmente
 * menores que 20.0. O método set também verifica se as coordenadas fornecidas
 * especificam um retângulo. Forneça métodos para calcular length, width,
 * perimeter e area. O comprimento é o maior das duas dimensões. Inclua um
 * método predicado isSquare que determina se o retângulo é um quadrado. Escreva
 * um programa para testar a classe Rectangle.
 */

package ch08.Exer08_14;

public class Exer08_14 {

}
