/*
 * Reescreva a Figura 8.14 para utilizar uma declaração import separada para
 * cada membro static da classe Math que é utilizado no exemplo.
 */

package ch08.Exer08_10;

public class Exer08_10 {

}
