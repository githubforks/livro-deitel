/*
 * (Jogo da velha) Crie uma classe TicTacToe que permitirá escrever um programa
 * completo para repriduzir o jogo da velha. A classe contém um array
 * bidimensional privado 3 por 3 de inteiros. O construtor deve inicializar a
 * grade vazia com todos como zero. Permita dois jogadores humanos. Para onde
 * quer que o primeiro jogador se mova, coloque um 1 no quadrado especificado;
 * coloque um 2 no local para o qual o segundo jogador se mover. Todo o
 * movimento deve ocorrer em um quadrado vazio. Depois de cada jogada, determine
 * se o jogo foi ganho e se aconteceu um empate. Se você se sentir motivado,
 * modifique o programa de modo que o computador faça o movimento par um dos
 * jogadores. Além disso, permita que o jogador especifiqueser que ser o
 * primeiro ou o segundo. Se você se sentir exepsionalmente motivado, desenvolva
 * um programa que jogue o Tic-Tac-Toe tridimensional em uma grade 4 por 4 por 4.
 * [Nota: Esse é um projeto desafiador que pode consumir muitas semanas de
 * esforço!]
 */

package ch08.Exer08_19;

public class Exer08_19 {

}
