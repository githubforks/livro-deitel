/*
 * (Classe Inteiro grande) Crie uma classe HugeInteger que utiliza um array de
 * 40 elementos de dígitos para armazenar inteiros com até 40 dígitos. Forneça
 * is métodos input, output, add e subtract. Para coparar objetos HugeInteger,
 * forneça os métodos aseguir: isEqualTo, isNotIqualTo, isGreaterThan, isLessThan,
 * isGreaterThanOrEqualTo. Cada um destes é um método predicado que retorna true
 * se o relacionamento estiver contido entre os dois objetos HugeInteger e retorna
 * false se o relacionamento não estiver contido. Forneça um método predicado
 * isZero. Se for ambicioso, forneça também os métodos multiply, divide e
 * remainde. [Nota: Valores booleanos primitivos podem ser gerados como as
 * palavras 'true' ou 'false' com o especificador de formato %b.]
 */

package ch08.Exer08_18;

public class Exer08_18 {

}
