/*
 * Escreva um código Java para começar a implementar o projeto da classe Keypad.
 */

package ch08.Exer08_03;

// A classe Keypad representa o teclado de um ATM
public class Keypad {
/*    // nenhum atributo foi especificado ainda

    // construtor sem argumento
    public Keypad()
    {
    } // Fim do construtor Keypad sem argumentos

    // Operações
    public int getInput()
    {
    } // Fim do método getInput
*/
} // Fim da classe Keypad
