/*
 * Escreva um tipo enum TrafficLight, cujas constantes (RED, GREEN, YELLOW)
 * aceitam um parâmetro - a duração da luz. Escreva um programa para testar o
 * enum TrafficLight de modo que ele exiba a constante enum e suas durações.
 */

package ch08.Exer08_11;

public class Exer08_11 {

}
