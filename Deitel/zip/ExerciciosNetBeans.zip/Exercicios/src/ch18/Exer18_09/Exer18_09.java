/*
 * Converta as classes TreeNode e Tree da Figura 17.17 em classes genéricas.
 * Para inserir um objeto em uma Tree, o objeto deve ser comparado aos objetos
 * nos nós da Tree existentes. Por essa razão, as classes TreeNode e Tree devem
 * especificar Conparable< E > como o limite superior de cada parâmetro de tipo
 * da classe. Depois de modificar as classes TreeNode e Tree, escreva um
 * apliativo de teste que cria três objetos Tree - um que armazena Integers, um
 * que armazena Doubles e outro que armazena Strings. Insira 10 valores em cada
 * árvore. Em seguida, gere a saída dos percursos na pré-ordem, na ordem e na
 * pós-ordem para cada Tree.
 */

package ch18.Exer18_09;

public class Exer18_09 {

}
