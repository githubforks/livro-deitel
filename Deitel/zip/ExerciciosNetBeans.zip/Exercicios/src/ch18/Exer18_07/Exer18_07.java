/*
 * Escreva uma versão genérica simples do método isEqualTo que compara seus dois
 * argumentos com o método equls e retorna true se forem iguais e false caso
 * contrário. Utilize esse método genérico em um programa que chama isEqualTo
 * com uma variedade de tipos predefinidos, como Object ou Integer. Qual
 * resultado você obtém ao tentar executar esse programa?
 */

package ch18.Exer18_07;

public class Exer18_07 {

}
