/*
 * (Protetor de tela com formas) Modifique sua solução do Exercício 12.19 para
 * que ele utilize a geração de números aleatórios a fim de escolher diferentes
 * formas a exibir. Utilize os métodos da classe Graphics.
 */

package ch12.Exer12_21;

public class Exer12_21 {

}
