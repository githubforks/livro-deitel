/*
 * (Triângulos aleatórios) Escreva um aplicativo que exibe triângulos gerados
 * aleatoriamente em cores diferentes. Cada triângulo deve ser preenchido com
 * uma cor diferente. Utilize a classe GeneralPath e o método fill da classe
 * Graphics2D para desenhar os triângulos.
 */

package ch12.Exer12_09;

public class Exer12_09 {

}
