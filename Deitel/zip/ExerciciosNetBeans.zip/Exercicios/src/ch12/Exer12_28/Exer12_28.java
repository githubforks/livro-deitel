/*
 * (Selecionando formas) Escreva um aplicativo que permite ao usuário selecionar
 * uma forma a partir de uma JComboBox e a desenha 20 vezes como posições e
 * dimensões aleatórias no método paintComponent. O primeiro item na JComboBox
 * deve ser a forma padrão que é exibida na primeira vez que paintComponent é
 * chamado.
 */

package ch12.Exer12_28;

public class Exer12_28 {

}
