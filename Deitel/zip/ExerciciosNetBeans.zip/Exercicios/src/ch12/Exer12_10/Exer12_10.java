/*
 * (Caracteres aleatórios) Escreva um aplicativo que desenha aleatoriamente
 * caracteres em diferentes tamanhos de fontes e cores.
 */

package ch12.Exer12_10;

public class Exer12_10 {

}
