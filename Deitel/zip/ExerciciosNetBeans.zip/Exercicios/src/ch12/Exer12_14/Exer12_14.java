/*
 * (Grade utilizando a classe Rectangle2D.Double) Modifique sua solução do
 * Exercício 12.13 para desenhar a grade utilizando classe Ractangle2D.Double e
 * o método draw da classe Graphics2D.
 */

package ch12.Exer12_14;

public class Exer12_14 {

}
