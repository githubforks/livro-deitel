/*
 * (Círculos cocêntricos utilizando a classe Ellipse2D.Double) Modifique sua
 * solução do Exercício 12.6 para desenhar as ovais utilizando a classe
 * Ellipse2D.Double e o método draw da classe Graphics2D.
 */

package ch12.Exer12_07;

public class Exer12_07 {

}
