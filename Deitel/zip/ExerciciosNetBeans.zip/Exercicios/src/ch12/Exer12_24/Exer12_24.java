/*
 * (Passeio do cavalo) Crie uma versão gráfica do problema de passeio do cavalo
 * (exercícios 7.22, 7.23 e 7.26). À medida que cada movimento é feito, a célula
 * apropriada do tabuleiro deve ser atualizada com o número adequado do
 * movimento. Se o resultado do programa é um tour completo ou um tour fechado,
 * o programa deve exibir uma mensagem apropriada. Se quiser, utilize a classe
 * Timer (veja o Exercício 12.19) para ajudar a animar o passeio do cavalo.
 */

package ch12.Exer12_24;

public class Exer12_24 {

}
