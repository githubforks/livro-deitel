/*
 * (Gráficos de tartaruga) Modifique sua solução do Exercício 7.21 - Gráficos de
 * tartaruga - para adicionar uma interface gráfica com o usuário utilizando
 * JTextFields e JButtons. Desenhe linhas em vez de asteriscos (*). Quando o
 * programa gráfico de tartaruga especificar um movimento, traduza o número de
 * posições em um número de pixels na tela multiplicando o número de posições
 * por 10. (ou qualquer valor que você escolher). Implemente o desenho com os
 * recursos da API do Java 2D.
 */

package ch12.Exer12_23;

public class Exer12_23 {

}
