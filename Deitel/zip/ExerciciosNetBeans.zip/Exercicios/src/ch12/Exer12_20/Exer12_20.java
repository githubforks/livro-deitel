/*
 * (Protetor de tela para um número aleatório de linhas) Modifique sua solução
 * do Exercício 12.19 para permitir que o usuário insira o número de linhas
 * aleatórias que deve ser desenhada antes de o aplicativo apagarseu próprio
 * desenho e começar a desenhar linhas novamente. Utilise um JTextField para
 * obter o valor. O usuário deve ser capar de digirar um novo número no
 * JTextField em qualquer momento durante a execução do programa. Utilize uma
 * classe interna para realizar o tratamento de eventopara o JTextField.
 */

package ch12.Exer12_20;

public class Exer12_20 {

}
