/*
 * (Gráfico de torta) Escreva um programa que insere quatro números e os dispõem
 * em um gráfico de torta. Utilize a classe Arc2D.Double e o método fill da
 * classe Graphics2D para realizar o desenho. Desenhe cada pedaço da torta em
 * uma cor separada.
 */

package ch12.Exer12_27;

public class Exer12_27 {

}
