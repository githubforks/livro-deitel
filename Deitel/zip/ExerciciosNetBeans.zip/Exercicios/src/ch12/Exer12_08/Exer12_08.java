/*
 * (Linhas aleatórias utilizando a classe Line2D.Double) Modifique a solução do
 * Exercício 12.7 para desenhar linhas aleatórias com cores aleatórias e
 * espessuras aleatórias de linha. Utilize a classe Line2D.Double e o método
 * draw da classe Graphics2D para desenhar as linhas.
 */

package ch12.Exer12_08;

public class Exer12_08 {

}
