/*
 * (Diálogo JColorChooser) Modifique o Exercício 12.28 para permitir ao usuário
 * selecionar a cor em que as formas devem ser desenhadas a partir de um diálogo
 * JColoChooser.
 */

package ch12.Exer12_30;

public class Exer12_30 {

}
