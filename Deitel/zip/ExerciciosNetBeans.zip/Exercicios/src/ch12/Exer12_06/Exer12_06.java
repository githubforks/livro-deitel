/*
 * (Círculos cocêntricos atualizando o método drawArc) Escreva um aplicativo
 * que escreva uma série de oito círculos cocêntricos. Os círculos devem ser
 * separados por 10 pixels. Utilize o método Graphics drawArc.
 */

package ch12.Exer12_06;

public class Exer12_06 {

}
