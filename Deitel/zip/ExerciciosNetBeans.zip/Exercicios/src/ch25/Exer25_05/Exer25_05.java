/*
 * Modifique o Exercicio 25.4 para fornecer uma JComboBox e uma TextArea a fim
 * de permitir ao usuário realizar uma consulta que seja selecionada a partir da
 * JComboBox ou definida na JTextArea. As consultas predefinidas de exemplo são:
 *      a) Selecione todos os empregados que trabalham no departamento de
 *         vendas.
 *      b) Selecione os empregados por hora que trabalham mais de 30 horas.
 *      c) Selecione todos os empregados comissionados em ordem decrescente da
 *         taxa de comissão.
 */

package ch25.Exer25_05;

public class Exer25_05 {

}
