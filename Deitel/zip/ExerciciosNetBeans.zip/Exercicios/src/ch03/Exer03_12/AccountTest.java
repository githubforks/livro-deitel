package ch03.Exer03_12;

public class AccountTest
{
	public static void main(String[] args)
	{
		
	}
}
