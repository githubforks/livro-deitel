package ch03.Exer03_14;

public class EmployeeTest
{
	public static void main(String[] args)
	{
		
	}
}
