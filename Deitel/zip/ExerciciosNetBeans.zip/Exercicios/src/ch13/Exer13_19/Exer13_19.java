/*
 * (Ordem de blocos catch) Escreva um programa que mostre que a ordem de blocos
 * catch é importante. Se você tentar capturar um tipo de exceção de superclasse
 * antes de um tipo de subclasse, o compilador deve gerar erros.
 */

package ch13.Exer13_19;

public class Exer13_19 {

}
