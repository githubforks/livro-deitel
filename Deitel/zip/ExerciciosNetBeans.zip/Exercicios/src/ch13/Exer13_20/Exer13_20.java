/*
 * (Falha de construtor) Escreva um programa que mostre um construtor que passa
 * informações sobre a falha do construtor para um handler de exceção. Defina a
 * classe SomeException, que lança um Exception no construtor. O programa deve
 * tentar criar um objeto do tipo SomeException e capturar a exceção que é
 * lançada do construtor.
 */

package ch13.Exer13_20;

public class Exer13_20 {

}
