/*
 * (Capturando exceções com superclasses) Utilize herança para criar uma
 * superclasse de exceção (chamada ExceptionA) e subclasses de exceção
 * ExceptionB e ExceptionC, em que ExceptionB herda de ExceptionA e ExceptionB
 * herda de ExceptionB. Escreva um programa para demonstrar que o bloco catch
 * para o tipo ExceptionA captura exeções de tipos ExceptionB e ExceptionC.
 */

package ch13.Exer13_17;

/**
 *
 * @author marcio
 */
public class Exer13_17 {

}
