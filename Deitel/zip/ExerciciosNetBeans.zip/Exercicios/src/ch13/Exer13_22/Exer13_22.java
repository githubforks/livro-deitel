/*
 * (Capturando exceções com ecopos esternos) Escreva um programa que mostre que
 * um método com seu próprio bloco try não precisa capturar todo possível erro
 * gerado dentro do try. Algumas exceções podem escorregar para, e serem
 * tratadas em, outros escopos.
 */

package ch13.Exer13_22;

public class Exer13_22 {

}
