/*
 * (Capturanco exceções com exceção de classe) Escreva um programa que demonstre
 * como várias exceções são capturadas com catch ( Exception exception ). Desta
 * vez, defina as classes ExceptionA (que herda da classe Exception) e
 * ExceptionB (que herda da classe ExceptionA). Em seu programa, crie blocos try
 * que lançam exceções de tipos ExceptionA, ExceptionB, NullPointerException e
 * IOException. Todas as exceções devem ser capturadas com blocos catch para
 * especificar o tipo Exception.
 */

package ch13.Exer13_18;

public class Exer13_18 {

}
