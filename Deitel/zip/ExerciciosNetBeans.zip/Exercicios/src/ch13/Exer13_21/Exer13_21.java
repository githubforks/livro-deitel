/*
 * (Relançando exceções) Escreva um programa que ilustre o relançamento de uma
 * exceção. Defina os métodos someMethod e someMethod2. O método someMethod2
 * deve lançar inicialmente uma exceção. O método someMethod deve chamar
 * someMethod2, capturar e relançá-la. Chame someMethod a partir do método main
 * e capture a exceção relançada. Imprima o rastreamento de pilha dessa exceção.
 */

package ch13.Exer13_21;

public class Exer13_21 {

}
