/*
 * (Método power recursivo) Escreva um método recursivo power( base , exponent )
 * que, quando chamado, retorna base^exponent. Por exemplo,
 * power( 3 , 4 ) = 3 * 3 * 3 * 3. Assuma que exponent é um inteiro maior ou
 * igual a 1. [Dica: O passo de recursão deve utilizar o relacionamento
 * base^exponent = base . base^exponent - 1 e a condição de terminação ocorre
 * quando exponent é igual a 1 porque base^1 = base. Incorepore esse método em
 * um programa que permita que o usuário insira base e exponent.]
 */

package ch15.Exer15_09;

public class Exer15_09 {

}
