/*
 * (Labirintos de qualquer tamanho) Generalize os métodos mazeTraversal e
 * mazeGenerator dos exercícios 15.20 e 15.21 para processar labirintos de
 * qualquer largura e altura.
 */

package ch15.Exer15_22;

public class Exer15_22 {

}
