/*
 * (Localize o valor mínimo em um array) Escreva um método recursiveMinimum que
 * determina o menor elemento em um array de inteiros. O método deve retornar
 * quando ele receber um array de um elemento.
 */

package ch15.Exer15_18;

public class Exer15_18 {

}
