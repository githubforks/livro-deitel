/*
 * (Máximo divisor comum) O máximo divisor comum dos inteiros x e y é o maior
 * inteiro que é divisível por x e y. Escreva um método recursivo mdc que
 * retorna o maximo divisor comum de x e y. O mdc de x e y é definido
 * recursivamente como segue: se y é igual a 0, então mdc(x,y) é x; caso
 * contrário, mdc(x,y) é mdc(y,x%y), onde % é o operador de resto. Utilize esse
 * método para substituir o que você ecreveu no aplicativo do Exercício 6.27.
 */

package ch15.Exer15_11;

public class Exer15_11 {

}
