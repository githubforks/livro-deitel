/*
 * (Pesquisa binária recursiva) Modifique a Figura 16.4 para utilizar o método
 * recursivo recursiveBinarySearch a fim de realizar uma pesquisa binária do
 * array. O método deve receber a chave de pesquisa, o índice inicial e o índice
 * final como argumentos. Se a chave de pesquisa for encontrada, seu indice no
 * array é retornado. Se a chave de pesquisa não for encontrada, é retornado -1.
 */

package ch16.Exer16_09;

public class Exer16_09 {

}
