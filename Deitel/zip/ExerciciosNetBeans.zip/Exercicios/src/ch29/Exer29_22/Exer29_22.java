/*
 * (Escrevendo o valor de um cheque por extenso) Continuando a discussão do
 * Exercicio 29.21, reiteramos a importância de se projetar sistemas de
 * preenchimento de cheques para impedir a alteração de valores do cheque. Um
 * método comum de segurança requer que o valor do cheque seja escrito em
 * números e 'por extenso' também. Mesmo se alguém for capaz de alterar o valor
 * numérico do cheque, e extremamente dificil alterar o valor por extenso.
 * Escreva um aplicativo que insira um valor do cheque numérico e escreva o
 * valor por extenso em inglês. Por exemplo, o valor 112,43 deve ser escrito
 * assim
 *      ONE hundred TWELVE and 43/100
 */

package ch29.Exer29_22;

public class Exer29_22 {

}
