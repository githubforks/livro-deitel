/*
 * Escreva suas próprias versões dos metodos de pesquisa String indexOf e
 * lastIndexOf.
 */

package ch29.Exer29_17;

public class Exer29_17 {

}
