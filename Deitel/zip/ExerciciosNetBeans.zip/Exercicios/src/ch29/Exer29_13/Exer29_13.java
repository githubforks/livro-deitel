/*
 * Escreva um aplicativo baseado no aplicativo do Exercício 29.12 que insira uma
 * linha de texto e utilize o método String indexOf para determinar o número
 * total de ocorrências de cada letra do alfabeto no texto. As letras minúsculas
 * e maiusculas devem ser contadas juntas. Armazene os totais para cada letra em
 * um array e imprima os valores em formato tabular depois que os totais forem
 * determinados.
 */

package ch29.Exer29_13;

public class Exer29_13 {

}
