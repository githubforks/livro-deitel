/*
 * (Imprimindo datas em vários formatos) As datas são impressas em vários
 * formatos comuns. Dois dos formatos mais comuns em inglês são
 *      04/25/1955 and April 25, 1955
 * Escreva um aplicativo que leia uma data no primeiro formato e imprima no
 * segundo formato.
 */

package ch29.Exer29_20;

public class Exer29_20 {

}
