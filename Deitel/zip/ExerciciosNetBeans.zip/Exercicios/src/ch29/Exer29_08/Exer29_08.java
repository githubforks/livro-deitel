/*
 * Escreva um aplicativo que insira um número de telefone como uma string na
 * forma (555) 555-5555. O aplicativo deve utilizar um objeto da classe
 * StringTokenizer para extrair o código de área como um token, os três
 * primeiros dígitos do número de telefone como um segundo token e os últimos
 * quatro dígitos do número de telefone como um terceiro token. Os sete dígitos
 * do número de telefone devem ser concatenados em uma string. O código de área
 * e o número de telefone devem ser impressos. Lembre-se de que você terá de
 * alterar caracteres delimitadores durante o processo de tokenizaçao.
 */

package ch29.Exer29_08;

public class Exer29_08 {

}
