/*
 * Escreva um aplicativo que leia uma palavra de cinco letras do usuário e
 * produza todas as possíveis palavras de três letras que podem ser derivadas
 * das letras da palavra de cinco letras. Por exemplo, as palavras de três
 * letras produzidas a partir da palavra 'bathe' incluem 'ate', 'bat', 'bet',
 * 'tab', 'hat', 'the' e 'tea'.
 */

package ch29.Exer29_18;

public class Exer29_18 {

}
