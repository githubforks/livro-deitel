/*
 * Declare uma subclasse de JPanel chamado MyColorChooser que fornece três
 * objetos JSlider e três objetos JTextField. Cada JSlider representa os valores
 * de O a 255 para as partes de azul, verde e vermelho de uma cor. Utilize esses
 * valores como os argumentos para o construtor Color a fim de criar um novo
 * objeto Color. Exiba o valor atual de cada JSlider no correspondente
 * JTextField. Quando o usuário altera o valor d JSlider, o JTextField deve ser
 * alterado correspondentemente. Utilize seu novo componente GUI como parte de
 * um aplicativo que exibe o vale Color atual desenhando um retângulo
 * preenchido.
 */

package ch22.Exer22_12;

public class Exer22_12 {

}
