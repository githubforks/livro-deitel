/*
 * (Aplicativo de desenho completo) Utilizando as técnicas desenvolvidas neste
 * capítulo e no Capítulo 11, crie um aplicativo de desenho completo. O programa
 * deve utilizar os componentes GUI dos capítulos 11 e 22 para permitir que o
 * usuário selecione as características de forma, cor e preenchimento. Cada
 * forma deve ser armazenada em um array de objetos MyShape, onde MyShape é a
 * superclasse na sua hierarquia das classes de forma. Utilize um JDesktopPane e
 * JInternalFrames para permitir ao usuário criar múltiplos desenhos separados
 * em janelas-filhas separadas. Crie a interface com o usuário como uma
 * janela-filha separada contendo todo o componente GUI que permite ao usuário
 * determinar as características da forma que será desenhada. O usuário então
 * pode clicar em qualquer JInternalFrame para desenhar a forma.
 */

package ch22.Exer22_17;

public class Exer22_17 {

}
