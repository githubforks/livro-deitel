/*
 * Modifique o aplicativo no Exercício 22.14 para permitir que usuário arraste o
 * mouse pelo painel de desenho (uma subclasse de JPanel) para desenhar uma
 * forma na cor atual. Permita ao usuário escolher que forma desenhar.
 */

package ch22.Exer22_15;

public class Exer22_15 {

}
