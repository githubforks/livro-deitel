/*
 * Modifique a classe MyColorChooser do Exercício 22.12 para permitir ao
 * usuário digitar um valor inteiro em um JTextField a fim configurar o valor de
 * vermelho, verde ou azul. Quando o usuário pressionar Enter no JTextField, o
 * JSlider correspondente deve ser configurado com o valor apropriado.
 */

package ch22.Exer22_13;

public class Exer22_13 {

}
