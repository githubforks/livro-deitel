/*
 * Aprimore o programa no Exercício 22.7 permitindo ao usuário alterar o raio
 * com um JSlider. O programa deve funcionar em todos os raios no intervalo de
 * 100 a 200. A medida que o raio muda, o diâmetro, a área e a circunferência
 * devem ser atualizados e exibidos. O raio inicial deve ser 150. Utilize as
 * equações do Exercicio 22.7. Todos os desenhos devem ser feitos em uma
 * subclasse de JPanel e os resultados dos cálculos devem ser exibidos em um
 * JtextArea de leitura.
 */

package ch22.Exer22_08;

public class Exer22_08 {

}
