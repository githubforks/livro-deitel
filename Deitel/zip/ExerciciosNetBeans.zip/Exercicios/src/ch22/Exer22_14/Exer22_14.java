/*
 * Modifique o aplicativo no Exercício 22.13 para desenhar a cor atual como um
 * retângulo em uma instância de uma subclasse do JPanel que fornece seu próprio
 * metodo paintComponent para desenhar o retângulo e forneça os métodos set para
 * configurar os valores de Verde, azul e vermelho para a cor atual. Quando um
 * método set é invocado, o painel de desenho deve automaticamente repintar
 * (repaint) a si próprio.
 */

package ch22.Exer22_14;

public class Exer22_14 {

}
