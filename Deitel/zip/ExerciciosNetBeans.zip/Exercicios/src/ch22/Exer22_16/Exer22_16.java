/*
 * Modifiqueo aplicativo no Exercício 22.15 para fornecer ao usuário a
 * capacidade de terminar o aplicativo clicando na caixa de fechamento na janela
 * que é exibida e selecionando Exit em um menu File. Utilize as técnicas
 * mostradas na Figura 22.5.
 */

package ch22.Exer22_16;

public class Exer22_16 {

}
