/*
 * Sistemas mais sofisticados de instruções auxiliadas por computador monitoram
 * o desempenho do estudante durante um período de tempo. A decisão sobre um
 * novo tópico freqüentemente é baseada no sucesso do estudante com tópicos
 * prévios. Modifique o programa do Exercício 6.31 para contar o número de
 * respostas corretas e incorretas digitadas pelo estudante. Depois que o aluno
 * digitar 10 respostas, seu programa deve calcular a porcentagem de respostas
 * corretas. Se a porcentagem for inferior a 75%, exiba 'Please ask your
 * instructor for extra help' [Peça ajuda ao seu instrutor] e reinicialize o
 * programa para que o outro estudante possa experimentá-lo.
 */

package ch06.Exer06_32;

public class Exer06_32
{
	public static void main( String args[] )
	{
		
	}
}
