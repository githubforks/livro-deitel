/*
 * Escreva um método isEven que utiliza o operador de resto (%) para determinar
 * se um inteiro é par. O método deve aceitar um argumento inteiro e retornar
 * true se o inteiro for par e false se o contrário. Incorpore esse método a um
 * aplicativo que insere uma sequência de inteiros (um por vez) e determina se
 * cada um é par ou ímpar.
 */

package ch06.Exer06_17;

public class Exer06_17
{
	public static void main ( String args[] )
	{
		
	}
}
