/*
 * Escreva um método minimum3 que retorna o menor de três números de ponto
 * flutuante. Utilize o método Math.min para implementar minimun3. Incorpore o
 * método a um aplicativo que lê três valores do usuário, determina o menor valor
 * e exibe o resultado.
 */

package ch06.Exer06_23;

public class Exer06_23
{
	public static void main( String args[] )
	{
		
	}
}
