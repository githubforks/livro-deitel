/*
 * Escreva um aplicativo que solicita ao usuário o raio de um círculo e
 * utiliza um método chamado circleArea para calcular a área do círculo.
 */

package ch06.Exer06_20;

public class Exer06_20
{
	public static void main ( String args[] )
	{
		
	}
}
