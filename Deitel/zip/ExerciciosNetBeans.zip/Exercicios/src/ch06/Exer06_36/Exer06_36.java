/*
 * Escreva um método 'distance' para calcular a distância entre dois pontos
 * (x1,y1) e (x2,y2). Todos os números e valores de retorno devem ser do tipo
 * double. Incorpore esse método a um aplicativo que permite que o usuário
 * insira coordenadas de pontos.
 */

package ch06.Exer06_36;

public class Exer06_36
{
	public static void main(String[] args)
	{

	}
}
