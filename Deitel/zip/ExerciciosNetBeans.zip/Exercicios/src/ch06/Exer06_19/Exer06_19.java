/*
 * Modifique o método criado no Exercício 6.18 para formar o quadrado a partir
 * de qualquer que seja o caracter contido no parâmetro de caractere
 * fillCharacter. Portanto, se side for 5 e fillCharacter for '#', o método
 * deve exibir
 *					#####
 *					#####
 *					#####
 *					#####
 *					#####
 */

package ch06.Exer06_19;

public class Exer06_19 {
	public static void main ( String args[] )
	{
		
	}
}
