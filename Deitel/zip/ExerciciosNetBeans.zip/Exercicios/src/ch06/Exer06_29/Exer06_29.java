/*
 * Escreva um aplicativo que simula o lançamento de uma moeda. Deixe o programa
 * lançar uma moeda toda vez que o usuário escolher a opção 'Toss Coin' no menu.
 * Conte o número de vezes que cada lado da moeda aparece. Exiba os resultados.
 * O programa deve chamar um método separado flip que não aceita nenhum
 * argumento e retorna false para coroa e true para cara. [Nota: Se o programa
 * simular o arremesso de moeda de maneira realista, cada lado da moeda da moeda
 * deve aparecer aproximadamente metade das vezes. ]
 */

package ch06.Exer06_29;

public class Exer06_29 {
	public static void main ( String args[] )
	{

	}
}
