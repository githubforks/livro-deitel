/*
 * Os exercícios 6.30 a 6.32 desenvolveram um programa de instrução auxiliada
 * por computador para ensinar multiplicação a um estudante do ensino
 * fundamental. Realize os seguintes aprimoramentos:
 *      a) Modifique o programa para permitir que o usuário insira uma
 *      capacidade de nível de graduação. Um nível de notas de 1 significa que o
 *      programa deve utilizar somente números de um dígito nos problemas, um
 *      nível de notas de 2 significa que o programa deve utilizar número de
 *      dois dígitos, e assim por diante.
 *
 *      b) Modifique o programa para permitir que o usuário selecione os tipos
 *      de problemas aritméticos que ele deseja estudar. Uma opção de 1
 *      significa apenas problemas de adição, 2 significa apenas problemas de
 *      subtração, 3 significa apenas problemas de multiplicação, 4 significa
 *      apenas problemas de divisão, e 5 significa uma combinação aleatória de
 *      problemas de todos esses tipos.
 */

package ch06.Exer06_35;

public class Exer06_35
{
	public static void main( String args[] )
	{
		
	}
}
