/*
 * Escreva um aplicativo que joga 'adivinhe o número' como aseguir: Seu programa
 * escolhe o número a ser adivinhado selecionando um inteiro aleatório no
 * intervalo de 1 a 1.000. O aplicativo exibe o prompt 'Guess a number between 1
 * and 1.000' [Adivinhe um número entre 1 e 1.000]. O jogador insere uma
 * primeira suposição. Se o palpite do jogador estiver incorreto, seu programa
 * deve exibir 'Too high. Try again.' [Muito alto. Tente novamente.] ou
 * 'Too low. Try again.' [Muito baixo. Tente novamente.]. Para ajudar o jogador a
 * 'zerar' mediante uma resposta correta, o programa solicitar ao usuário o
 * próximo palpite. Quando o jogador inserir uma resposta correta, exiba
 * 'Congratulations. You guessed the number!' [Parabéns. Você adivinhou o
 * número!] e permita ao jogador escolher se que jogar novamente. [Nota:  A
 * técnica de adivinhação empregada nesse problema é semelhante a uma pesquisa
 * binária, discutida no Capítulo 16.]
 */

package ch06.Exer06_33;

public class Exer06_33
{
	public static void main ( String args[] )
	{
		
	}
}
