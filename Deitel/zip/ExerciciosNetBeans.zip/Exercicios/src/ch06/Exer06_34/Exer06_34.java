/*
 * Modifique o programa do Exercício 6.33 para contar o número de suposições que
 * o jogador faz. Se o número for 10 ou menos, exiba
 * 'Either you know the secret or you got lucky' [Você sabe o segredo ou tem
 * muita sorte!] se o jogador adivinhar o número em 10 tentativas, exiba
 * 'Aha, you know the secret!' [Aha, você sabe o segredo!]. Se o jogador fizer
 * mais que 10 adivinhações, exiba 'You should be able do to better!' [Você é
 * capaz de fazer melhor!]. Por que esse jogo não deve precisar mais que 10
 * suposições? Bem, a cada 'boa suposição' o jogador deve ser capaz de eliminar
 * metade dos números. Agora mostre por que qualquer número 1 a 1.000 pode ser
 * advinhado em 10 ou menos tentativas.
 */

package ch06.Exer06_34;

public class Exer06_34
{
	public static void main ( String args[] )
	{
		
	}
}