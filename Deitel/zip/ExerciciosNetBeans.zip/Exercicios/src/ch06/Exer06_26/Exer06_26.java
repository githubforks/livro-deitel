/*
 * Escreva um método que aceita um valor inteiro e retorna o número com seus
 * dígitos invertidos. Por exemplo, dado o número 7.631, o método deve retornar
 * 1.367. Incorpore o método a um aplicativo que lê um valor a partir da entrada
 * fornecida pelo usuário e exibe o resultado.
 */

package ch06.Exer06_26;

public class Exer06_26
{
	public static void main ( String args[] )
	{
		
	}
}
