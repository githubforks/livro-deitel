/*
 * Escreva um aplicativo que exibe uma tabela de equivalentes binários octal e
 * hexadecimal dos números decimais no intervalo 1 a 256. Se você não estiver
 * familiarizado com esses sistemas numéricos, leia o apêndice E primeiro.
 */

package ch06.Exer06_38;

public class Exer06_38 {

}
