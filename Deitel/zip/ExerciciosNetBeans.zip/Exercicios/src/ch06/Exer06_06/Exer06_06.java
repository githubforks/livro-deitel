/*
 * Escreva um aplicativo Java completo para solicitar ao usuário um raio (do tipo double)
 * de uma esfera e chame o método sphereVolume para calcular e exibir o volume da esfera.
 * Utilize a seguinte instrução para calcular o volume:
 * 
 * 					double volume = (4.0/3.0) * Math.PI * Math.pow(radius, 3)
 */

//Exercício 6.6
//Calcula o volume de uma esfera

package ch06.Exer06_06;

public class Exer06_06
{

}
