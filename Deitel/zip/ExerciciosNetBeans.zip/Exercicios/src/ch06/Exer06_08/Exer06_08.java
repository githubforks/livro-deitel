/*
 * 	Um estacionamento cobra uma taxa mínima de $ 2 para estacionar por até 3
 * horas. Um adicional de $ 0,50 por hora não necessariamente inteira é cobrado
 * após as três primeiras horas. A carga máxima para qualquer dado período de 24
 * horas é $ 10. Suponha que nenhum carro fica estacionado por mais de 24 horas
 * por vez. Escreva um aplicativo que calcule e exiba as taxas de estacionamento
 * para cada cliente que estacionou nessa garagem ontem. Você deve inserir as
 * horas de estacionamento para cada cliente. O programa deve exibir a cobrança
 * para o cliente atual e calcular e exibir o total dos recibos de ontem. O
 * programa deve utilizar o método calculateCharges para determinar a cobrança
 * para cada cliente.
 */

package ch06.Exer06_08;

public class Exer06_08
{
	public static void main(String[] args)
	{
		
	}
}
