/*
 * O máximo divisor comum (MDC) de dois inteiros é o maior inteiro que é
 * divisível por cada um dos dois números. Escreva um método mdc que retorna o
 * máximo divisor comum entre dois inteiros. Incorpore o método a aplicativo que
 * lê dois valores do usuário e exibe o resultado.
 */

package ch06.Exer06_27;

public class Exer06_27 {
	public static void main ( String args[] )
	{
		
	}
}
