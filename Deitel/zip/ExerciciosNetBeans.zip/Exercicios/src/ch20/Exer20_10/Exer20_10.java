/*
 * A classe Graphics contém o método drawOval, que recebe como argumentos os
 * mesmos quatro argumentos do método drawRect. Os argumentos do método drawOval
 * especificam o quadro delimitador da oval - os lados do quadro delimitador são
 * os limites da oval. Escreva um applet Java que desenha uma oval e um
 * retângulo com os mesmos quatro argumentos. A oval tocará o retangulo no
 * centro de cada lado.
 */

package ch20.Exer20_10;

public class Exer20_10 {

}
