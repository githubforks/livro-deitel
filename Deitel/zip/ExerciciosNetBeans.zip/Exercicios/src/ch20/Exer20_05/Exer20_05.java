/*
 * Escreva um applet que pede para o usuário inserir o raio de um círculo como
 * um número de ponto flutuante e desenha o diâmetro do círculo, circunferência
 * e área. Utilize o valor 3,14159 para π. Utilize as técnicas mostradas na
 * Figura 20.10. [Nota: Você também pode utilizar a conste Math.PI predefinida
 * para o valor de π. Essa constante é mais precisa queo valor 3,14159. A classe
 * Math é definida no pacote java.lang, logo não é preciso importá-la.] Utilize
 * as seguintes fórmulas (r é o raio):
 *
 * diâmetro = 2r
 * circunferência = 2πr
 * área = πr^2
 */

package ch20.Exer20_05;

public class Exer20_05 {

}
