/*
 *  Escreva um applet que desenha um padrão de tabuleiro de damas como segue:
 *
 *              * * * * * * * *
 *               * * * * * * * *
 *              * * * * * * * *
 *               * * * * * * * *
 *              * * * * * * * *
 *               * * * * * * * *
 *              * * * * * * * *
 *               * * * * * * * *
 */

package ch20.Exer20_07;

public class Exer20_07 {

}
