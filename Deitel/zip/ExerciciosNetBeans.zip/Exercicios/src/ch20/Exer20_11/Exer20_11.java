/*
 * Modifique a solução do Exercicio 20.10 para gerar a saída de ovais de
 * diferentes formas e tamanhos.
 */

package ch20.Exer20_11;

public class Exer20_11 {

}
