/*
 * Escreva um applet que pede para o usuário inserir dois números de ponto
 * flutuante, obtém do usuário os números e primeiro exibe os dois números e
 * então o maior número seguido pelas palavras "is larger" como uma string no
 * applet. Se os numeros forem iguais, o applet deve imprimir a mensagem
 * "These numbers are equal". Utilize as técnicas mostradas na Figura 20.10.
 */

package ch20.Exer20_03;

public class Exer20_03 {

}
