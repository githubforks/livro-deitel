/*
 * (Transição aleatória entre imagens) Este exercício fornece um efeito visual
 * muito interessante. Se você estiver exibindo uma imagem em determinada área
 * na tela e quiser fazer uma transicão para outra imagem na mesma área,
 * armazene a nova imagem de tela em um buffer fora da tela e copie
 * aleatoriamente pixels dela para a área de exibição, sobre os pixels já nessas
 * localizações. Quando a maioria dos pixels tiver sido copiada, copie a nova
 * imagem inteira para a área de exibição a fim de se certificar de que você
 * está exibindo a nova imagem completa. Para implementar esse programa você
 * pode precisar utilizar as classes PixelGrabber e MemoryImageSource (veja a
 * documenlação da API do Java para descrições dessas classes). Você poderia
 * tentar diversas variantes desse problema. Por exemplo, selecione todos os
 * pixels em uma linha reta ou forma selecionada aleatoriamente na nova imagem e
 * cubra as posições correspondentes da antiga imagem.
 */

package ch21.Exer21_14;

public class Exer21_14 {

}
