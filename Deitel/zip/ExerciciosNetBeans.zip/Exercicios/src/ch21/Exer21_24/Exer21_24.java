/*
 * (Jogo de malha) Desenvolva uma simulação baseada em multimídia do jogo de
 * malha. Utilize áudio e efeitos visuais apropriados.
 */

package ch21.Exer21_24;

public class Exer21_24 {

}
