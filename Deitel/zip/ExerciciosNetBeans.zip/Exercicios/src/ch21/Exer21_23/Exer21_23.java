/*
 * (Corrida de cavalos) Crie uma simulação Java de uma corrida de cavalos com
 * múltiplos competidores. Utilize áudios para um apresentador da corrida.
 * Reproduza os áudios adequados para indicar o status correto de cada
 * competidor durante toda a corrida. Utilize áudios para anunciar os resultados
 * finais. Você poderia tentar simular os jogos de corrida de cavalos que
 * freqüentemente ocorrem em parques de diversões. Os jogadores revezam-se em
 * turnos para usar o mouse e e devem utilizar suas habilidades manuais para
 * avançar seus cavalos.
 */

package ch21.Exer21_23;

public class Exer21_23 {

}
