/*
 * (Painel de caracteres rolantes) Crie um programa Java que role caracteres da
 * direita para esquerda (ou da esquerda para a direita, se isso for apropriado
 * para seu idioma) ao longo de um painel de exibição. Como uma opção, exiba o
 * texto em um loop contínuo, de modo que, depois que o texto desaparecer em uma
 * extremidade, ele reapareça na outra.
 */

package ch21.Exer21_16;

public class Exer21_16 {

}
