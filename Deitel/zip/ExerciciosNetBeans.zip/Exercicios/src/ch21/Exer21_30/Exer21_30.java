/*
 * (Jogo dos 15) Escreva um programa em Java baseado em multimídia que permita
 * ao usuário jogar o jogo dos 15, que ocorre em um tabuleiro de 4 por 4 em um
 * total de 16 slots. Um deles está vazio, os outros estão ocupados por 15 peças
 * quadradas numeradas de 1 a 15. Qualquer peça ao lado do slot vazio pode ser
 * movida para essa posição clicando no ladrilho. Seu programa deve criar o
 * tabuleiro com os ladrilhos fora de ordem. O objetivo é organizar os ladrilhos
 * na ordem sequencial linha por linha.
 */

package ch21.Exer21_30;

public class Exer21_30 {

}
