/*
 * (Flasher de imagem) Crie um programa Java que faça uma imagem piscar
 * repetidamente na tela. Faça isso alternando a imagem com outra imagem
 * simples de cor do fundo.
 */

package ch21.Exer21_08;

public class Exer21_08 {

}
