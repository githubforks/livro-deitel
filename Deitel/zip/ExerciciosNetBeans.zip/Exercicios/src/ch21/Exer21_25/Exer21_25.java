/*
 * (Jogo de bilhar) Crie uma simulação baseada em multimídia do jogo de bilhar.
 * Cade jogador reveza-se em turnos para usar o mouse afim de posicionar um taco
 * de bilhar e acertá-lo contra bola no ângulo adequado e fazer com que as
 * outras bolas caiam nos bolsos. Seu programa deve manter uma contagem.
 */

package ch21.Exer21_25;

public class Exer21_25 {

}
