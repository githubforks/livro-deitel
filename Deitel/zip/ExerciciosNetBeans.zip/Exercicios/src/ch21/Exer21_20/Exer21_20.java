/*
 * (Gerador automático de quebra-cabeça) Crie um gerador e manipulador Java de
 * quebra-cabeça. Primeiro, o usuário especifica uma imagem. O programa carrega
 * e exibe a imagem e depois a divide em formas selecionadas aleatoriamente e as
 * embaralha. O usuário então utiliza o mouse para mover as peças a fim de
 * resolver o quebra-cabeça. Adicione sons de áudio de movimento e encaixe
 * adequados. Você poderia controlar a posição de cada peça e então utilizar os
 * efeitos de áudio para ajudar o usuário a encaixar as peças nas posições
 * correras.
 */

package ch21.Exer21_20;

public class Exer21_20 {

}
