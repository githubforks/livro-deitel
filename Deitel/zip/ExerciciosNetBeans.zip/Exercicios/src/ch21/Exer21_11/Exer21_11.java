/*
 * (Ampliador de imagem) Crie um programa que permita ampliar e reduzir uma
 * imagem.
 */

package ch21.Exer21_11;

public class Exer21_11 {

}
