/*
 * (Testador de precisão de reação/tempo de reação) Crie um programa Java que
 * mova uma forma criada aleatoriamente pela tela. O usuário move o mouse para
 * capturar e clicar na forma. A velocidade e o tamanho da forma podem ser
 * variados. Mantenha estatísticas sobre o tempo que o usuário geralmente leva
 * para perceber uma forma de determinado tamanho. Ele provavelmente terá mais
 * dificuldade para capturar mais rapidamente formas menores em movimento.
 */

package ch21.Exer21_31;

public class Exer21_31 {

}
