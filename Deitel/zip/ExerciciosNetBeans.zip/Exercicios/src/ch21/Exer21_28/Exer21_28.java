/*
 * (Plonejador de planta baixa) Desenvolva um programa Java que possa ser
 * utilizado para organizar os móveis em uma casa. Adicione recursos que
 * permitam que seja obtida a melhor disposição possível.
 */

package ch21.Exer21_28;

public class Exer21_28 {

}
