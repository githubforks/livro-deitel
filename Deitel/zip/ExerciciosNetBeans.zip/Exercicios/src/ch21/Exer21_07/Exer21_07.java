/*
 * (Flasher de texto) Crie um programa Java que faça um texto piscar
 * repetidamente na tela. Faça isso alternando o texto com uma imagem simples de
 * cor do fundo. Permita que o usuário controle a 'velocidade de piscamento' e a
 * cor ou padrão de fundo. Você precisará utilizar métodos getDelay e setDelay
 * da classe Timer. Esses métodos são utilizados para recuperar e configurar o
 * intervalo em milissegundos entre ActionEvents, respectivamente.
 */

package ch21.Exer21_07;

public class Exer21_07 {

}
