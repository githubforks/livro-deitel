/*
 * (Arquivo de calendário/lembretes) Utilizando tanto áudio como imagens, crie
 * um arquivo de calendário e 'lembretes' de uso geral. Por exemplo, o programa
 * deve tocar 'Feliz Aniversário' quando você utilizá-lo em seu aniversario.
 * Faça com que o programa exiba imagens e reproduza áudios associados com
 * eventos importantes. Além disso, faça o programa lembrá-lo com antecedência
 * desses importantes eventos. Seria interessante, por exemplo, fazer o programa
 * fornecer um aviso com uma semana de antecedência, de modo que você possa
 * enviar um cartão de felicitações apropriado para uma pessoa especial.
 */

package ch21.Exer21_32;

public class Exer21_32 {

}
