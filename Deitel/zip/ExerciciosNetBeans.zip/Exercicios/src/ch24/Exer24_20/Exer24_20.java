/*
 * (Jogo de pôquer) Desenvolva um jogo de cartas de pôquer em que o aplicativo
 * servidor dá as cartas para cada um dos applets clientes. O servidor deve
 * distribuir as cartas adicionais (de acordo com as regras do jogo) para cada
 * jogador quando solicitado.
 */

package ch24.Exer24_20;

public class Exer24_20 {

}
