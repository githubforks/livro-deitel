/*
 * Modifique o programa na Figura 24.2 para permitir aos usuários adicionar e
 * remover seus próprios sites da lista.
 */

package ch24.Exer24_15;

public class Exer24_15 {

}
