/*
 * Modifique o Exercicio 24.13 para permitir ao cliente modificar o conteúdo do
 * arquivo e enviar o arquivo de volta ao servidor para armazenamento. O usuário
 * pode editar o arquivo em uma JTextArea, então dique em um botão
 * 'salvar alrações' para enviar o arquivo de volta ao servidor.
 */

package ch24.Exer24_14;

public class Exer24_14 {

}
