/*
 * Os servidores multiencadeados são bem populares hoje, especialmente por causa
 * da utilização crescente de servidores multiprocessados. Modifique a aplicação
 * de servidor simples apresentada na Secão 24.6 para ser um servidor com
 * múltiplas threads. Então utilize vários aplicatiws clientes e faça cada um
 * deles se conectar ao servidor simultaneamente. Utilize um ArrayList para
 * armazenar as threads de cliente. O ArrayList fornece vários métodos de uso
 * neste exercício. O método size determina o número de elementos em um
 * ArrayList. O método get retorna o elemento na localização especificada pelo
 * seu argumento. O método add coloca seu argumento no fim do ArrayList. O
 * método remove exclui seu argumento do ArrayList.
 */

package ch24.Exer24_16;

public class Exer24_16 {

}
