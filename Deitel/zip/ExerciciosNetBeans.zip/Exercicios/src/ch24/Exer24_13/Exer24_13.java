/*
 * Utilize uma conexão de socket para permitir a um cliente especificar um nome
 * de arquivo e fazer o servidor enviar o conteúdo do arquivo ou indicar que o
 * arquivo não existe.
 */

package ch24.Exer24_13;

public class Exer24_13 {

}
