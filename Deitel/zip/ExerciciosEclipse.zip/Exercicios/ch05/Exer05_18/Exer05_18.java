/*
 * Modifique o aplicativo na Figura 5.6 para utilizar apenas inteiros para
 * calcular juros compostos [Dica: Trate todas as quantidades monetárias como
 * números inteiros em centavos. Então divida o resultado em suas partes dólar e
 * centavos utilizando as operações divisão e resto respectivamente. Insira uma
 * vírgula entre as partes dólar e centavos.]
 * 
 *  1 ->       5 x 10^ -2
 *  2 ->      25 x 10^ -4
 *  3 ->     125 x 10^ -6
 *  4 ->     625 x 10^ -8
 *  5 ->    3125 x 10^-10
 *  6 ->   15625 x 10^-12
 *  7 ->   78125 x 10^-14
 *  8 ->  390625 x 10^-16
 *  9 -> 1953125 x 10^-18
 * 10 -> 9765625 x 10^-20
 */

package ch05.Exer05_18;

public class Exer05_18
{
	public static void main(String[] args)
	{
		
	}
}
