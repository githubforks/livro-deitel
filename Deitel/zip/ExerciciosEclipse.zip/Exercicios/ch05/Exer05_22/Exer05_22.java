/*
 * Modifique o Exercício 5.15 para combinar seu código dos quatro triângulos de
 * asteriscos, separados de modo que todos os quadrados padrões sejam impressos
 * lado a lado. Faça uso inteligente de loops for aninhados.
 */

package ch05.Exer05_22;

public class Exer05_22
{
	public static void main(String[] args)
	{
		
	}
}
