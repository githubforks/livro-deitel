/*
 * Escreva um aplicativo que imprima s seguinte forma de losango. Você pode
 * utilizar instruções de saída que imprima um único asterisco (*), um único
 * espaço ou um único caractere de nova linha. Maximize sua utilização de
 * repetição (com instruções for aninhadas) e minimize o número de instruções de
 * saída.
 * 
 *                 *
 *                ***
 *               *****
 *              *******
 *     	       *********
 *              *******
 *               *****
 *                ***
 *                 *
 */

package ch05.Exer05_24;

public class Exer05_24
{
	public static void main(String[] args)
	{
		
	}
}
