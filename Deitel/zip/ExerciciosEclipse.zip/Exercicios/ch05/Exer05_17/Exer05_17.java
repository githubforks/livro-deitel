/*
 * Uma empresa que faz negócios por reembolso postal vende cinco produtos cujos
 * preços de varejo são como segue: Produto 1, $ 2,98; Produto 2, $ 4,50;
 * Produto 3, $ 9,98; Produto 4, $ 4,49 e produto 5, $ 6,87. Escreva um
 * aplicativo que leia uma série de pares de números
 * como segue:
 * 		a) número de produto
 * 		b) quantidade vendida
 * Seu programa deve utilizar uma instrução switch para determinar o preço de
 * varejo de cada produto. Você deve calcular e exibir o valor de varejo total
 * de todos os produtos vendidos. Utilize um loop controlado por sentinela para
 * determinar quando o programa deve parar o loop e exibir os resultados finais.
 */

package ch05.Exer05_17;

public class Exer05_17
{
	public static void main(String[] args)
	{
		
	}
}
