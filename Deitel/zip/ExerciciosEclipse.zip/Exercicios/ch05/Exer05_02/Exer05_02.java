/*
 * Modifique o Exercício 5.16 no final dos exercícios do capítulo para ler a entrada
 * utilizando diálogos e exibir o gráfico de barras utilizando retângulos de comprimentos
 * variados.
 */

package ch05.Exer05_02;

public class Exer05_02 {
	public static void main(String[] args)
	{
		
	}
}
