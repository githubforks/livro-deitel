/*
 * Modifique o programa de juros compostos da Figura 5.6 para repetir seus passos para taxas
 * de juros de 5%, 6%, 7%, 8%, 9% e 10%. Utilize um loop for para variar a taxa de juros.
 */

package ch05.Exer05_14;

public class Exer05_14 {
	public static void main( String args[] )
	{
		
	}
}
