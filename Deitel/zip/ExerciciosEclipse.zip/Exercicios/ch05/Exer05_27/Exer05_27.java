/*
 * O que o seguinte segmento de programa faz ?
 *
 * [Nota: A cada três linhas imprimindo 4 asteriscos, imprime
 * uma linha em branco.]
 */

package ch05.Exer05_27;

public class Exer05_27 {
	public static void main ( String args[] )
	{
		
	}
}
