/*
 * Escreva um aplicativo que localiza o menor de vários inteiros. Assuma que o
 * primeiro valor lido especifica o número de valores a serem inseridos pelo
 * usuário.
 */
package ch05.Exer05_11;

public class Exer05_11
{
    public static void main (String args[])
    {
    	
    }
}
