/*
 * Descreva de maneira geral como você removeria qualquer instrução continue
 * de um loop em um programa e a substituiria por alguma equivalente
 * estruturada. Utilize a técnica que você desenvolve aqui para remover a
 * instrução continue do programa na Figura 5.13.
 *
 * [Nota: Nesse caso utiliza count++ dentro do loop para "pular" um número e
 *  coloca-se o restante do código dentro de um bloco.]
 */

package ch05.Exer05_28;

public class Exer05_28
{
	public static void main( String args[] )
	{
		
	}
}
