/*
 * (Buble sort aprunorado) Faça as modificações simples a seguir para melhorar o
 * desempenho do bublesort que você desenvolveu no Exercício 16.5:
 *      a) Depois da primeira passagem, garante-se que o número maior está no
 * elemento de número mais alto do array, após a segunda passagem, o dois
 * números mais altos estão 'no lugar'; e assim por diante. Em vez de fazer nove
 * comparações em cada passagem, modifique o bubble sort para fazer oito
 * comparações na segunda passagem, sete na terceira passagem, e assim por
 * diante.
 *      b) Os dados no array já podem estar na ordem adequada ou na ordem quase
 * adequada. Então por que fazer nove passagens se menos seriam suficientes?
 * Modifique a classificação para verificar no fim de cada passagem se alguma
 * permuta foi feita. Se nenhuma permuta tiver sido feita, os dados já devem
 * estar na ordem apropriada; então o programa deve terminar. Se permutas foram
 * feitas, pelo menos mais uma passagem é necessária.
 */

package ch16.Exer16_06;

public class Exer16_06 {

}
