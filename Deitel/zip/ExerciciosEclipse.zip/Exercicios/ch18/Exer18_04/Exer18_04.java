/*
 * Escreva um método genérico selectionSort com base no programa de
 * classificação das figuras 16.6 e 16.7. Escreva um programa de teste que
 * insere, classifica e gera saída de um array Integer e de um array F1oat.
 * [Dica: Utilize < T extends Comparable< T > > na seção de parâmetro de tipo
 * para o método selectionSort, de modo que ele possa utilizar o método
 * compareTo para comparar os objetos de dois tipos genéricos T.]
 */

package ch18.Exer18_04;

public class Exer18_04 {

}
