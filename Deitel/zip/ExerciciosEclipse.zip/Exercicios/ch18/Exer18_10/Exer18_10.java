/*
 * Modifique seu programa de teste no Exercicio 18.9 para que ele utilize um
 * método genérico chamado testTree para testar os três objetos Tree. O método
 * deve ser chamado três vezes - uma vez para cada objeto Tree.
 */

package ch18.Exer18_10;

public class Exer18_10 {

}
