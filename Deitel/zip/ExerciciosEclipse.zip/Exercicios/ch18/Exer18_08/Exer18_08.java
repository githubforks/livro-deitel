/*
 * Escreva uma classe genérica Pair que tem dois parâmetros de tipo - F e S,
 * cada um representando, respectivamente, o tipo do primeiro e tipo do segundo
 * elemento do par. Adicione os métodos get e set ao primeiro e ao segundo
 * elemento do par. [Dica: O cabeçalho da classe deve ser public class
 * Pair< F, S >.]
 */

package ch18.Exer18_08;

public class Exer18_08 {

}
