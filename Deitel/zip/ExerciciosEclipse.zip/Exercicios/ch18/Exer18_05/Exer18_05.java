/*
 * Sobrecarregue o método genérico printArray da Figura 18.3 de modo que ele
 * aceite dois argumentos adicionais de inteiros, lowSubscript e highSubscript.
 * Uma chamada a esse método imprime somente a parte especificada do array.
 * Valide lowSubscript e highSubscript. Se estiver fora do intervalo ou se
 * highSubscript for menor ou igual a lowSubscript, o método printArray
 * sobrecarregado deve lançar uma InvalidSubscriptException; caso contrário,
 * printArray deve retornar o número de elementos impresso. Em seguida modifique
 * o método main para praticar as duas versões de printArray nos arrays
 * integerArray, doubleArray e characterArray. Teste todas as capacidades das
 * duas versões de printArray.
 */

package ch18.Exer18_05;

public class Exer18_05 {

}
