/*
 * Sobrecarregue o método genérico printArray da Figura 18.3 com uma versão
 * não-genérica que imprime especificamente um array de strings em formato
 * tabular elegante, como mostrado na saida do exemplo a seguir:
 *
 * Array stringArray contains:
 * one      two      three      four
 * five     six      seven      eight
 */

package ch18.Exer18_06;

public class Exer18_06 {

}
