/*
 * 		Escreva um programa que insere cinco números e determina e imprime quantos números
 * negativos, quantos número positivos e quantos zeros foram inseridos.
 */

package ch02.Exer02_32;

public class Exer02_32
{
	public static void main(String[] args)
	{
		
	}
}
