/*
 * Escreva um aplicativo que lê dois inteiros, determina se o primeiro é
 * múltiplo do segundo e imprime o resultado. [Dica: Utilize o operador de
 * módulo.]
 */

package ch02.Exer02_26;

public class Exer02_26
{
	public static void main(String[] args)
	{
		
	}
}
