/*
 * Utilizando apenas as técnicas de programação que você aprendeu neste capítulo, escreva um
 * aplicativo que calcula os quadrados e os cubos dos números de 0 a 10 e imprima os valores
 * resultantes no formato de tabela como asseguir
 * número quadrado cubo
 * 0      0        0
 * 1      1        1
 * 2      4        8
 * 3      9        27
 * 4      16       64
 * 5      25       125
 * 6      36       216
 * 7      49       343
 * 8      64       512
 * 9      81       729
 * 10     100      1000
 */

package ch02.Exer02_31;

public class Exer02_31
{
	public static void main(String[] args)
	{
		
	}
}
