/*
 * Escreva um aplicativo que solicita ao usuário inserir dois inteiros, obtém do
 * usuário esses números e imprime sua soma, produto, diferença e quociente
 * (divisão). Utilize as técnicas mostradas na Figura 2.7.
 */

package ch02.Exer02_15;

public class Exer02_15
{
	public static void main(String[] args)
	{
		
	}
}
