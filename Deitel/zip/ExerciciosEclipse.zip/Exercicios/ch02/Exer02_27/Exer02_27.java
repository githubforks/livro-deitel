/*
 * Escreva um aplicativo que exibe um padrão de tabuleiro de damas, como a
 * seguir:
 *                          * * * * * * * *
 *                           * * * * * * * *
 *                          * * * * * * * *
 *                           * * * * * * * *
 *                          * * * * * * * *
 *                           * * * * * * * *
 *                          * * * * * * * *
 *                           * * * * * * * *
 */

package ch02.Exer02_27;

public class Exer02_27
{
	public static void main(String[] args)
	{
		
	}
}
