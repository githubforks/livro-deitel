/*
 * (Embaralhamento e distribuição de cartas) Modifique o aplicativo desenvolvido
 * no Exercício 7.31 para que possa simular o carteador. A mão de cinco cartas
 * do carteador é distribuída 'no escuro', então o jogador não pode vê-la. O programa
 * deve avaliar a mão do carteador e com base na qualidade da mão, o carteador deve
 * distribuir uma, duas ou três mais cartas para substituiro número correspondente
 * de cartas desnecessárias na mão original. [Atenção: Esse é um problema difícil!]
 */

package ch07.Exer07_32;

public class Exer07_32 {

}
