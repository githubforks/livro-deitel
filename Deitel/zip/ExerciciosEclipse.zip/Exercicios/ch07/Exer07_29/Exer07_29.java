/*
 * (Série de Fibonacci) A série de Fibonacci
 *      0, 1, 1, 2, 3, 5, 8, 13, 21,...
 * inicia com os termos 0 e 1 e tem a propriedade de que cada termo sucessivo é
 * a soma dos dois termos precedentes.
 *
 *      a) Escreva o método fibonacci( n ) que calcula a n-ésimo termo da série
 * de Fibonacci. Incorpore esse método a um aplicativo que permita ao usuário
 * inserir o valor de n.
 *
 *      b) Determine o maior número de Fibonacci que pode ser exibido em seu
 * sistema.
 *
 *      c) Modifique o aplicativo que você escreveu na parte (a) para utilizar
 * double em vez de int para calcular e retornar números de Fibonacci e utilizar
 * esse aplicativo midificado para repetir a parte (b).
 */

package ch07.Exer07_29;

public class Exer07_29 {

}
