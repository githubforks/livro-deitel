/*
 * (Embaralhamento e distribuição) Modifique o aplicativo na Figura 7.11 pars
 * distribuir uma mão de cinco cartas de pôker. Então modifique a classe
 * deckOfCards da Figura 7.10 para incluir métodos que determinam se um mão contém
 *
 *      a) um par
 *      b) dois pares
 *      c) uma trinca (por exemplo, três valetes)
 *      d) uma quadra (por exemplo, quatro ases)
 *      e) um flush (isto é, cinco cartas do mesmo nipe)
 *      f) um straight (isto é, cinco cartas de valores consecutivos)
 *      g) uma full house (isto é, duas cartas de um valor e três cartas de outro valor)
 *
 * [Dica: Adicione os métodos getFace e getSuit à classe card da Figura 7.9]
 */

package ch07.Exer07_30;

public class Exer07_30 {

}
