/*
 * (Passeio do cavalo: teste do passeio do cavalo) No passeio do cavalo (Exercício
 * 7.22), um passeio completo acontece quando o cavalo se move tocando cada um
 * dos 64 quadrados do tabuleiro de xadrez unicamente uma vez. Um passeio fechado
 * ocorre quando o 64º movimento cai no quadrado em que o cavalo iniciou o passeio.
 * Modifique o aplicativo no Exercício 7.22 para testar o caso de um passeio
 * fechado se um passeio completo tiver ocorrido.
 */

package ch07.Exer07_26;

public class Exer07_26 {

}
