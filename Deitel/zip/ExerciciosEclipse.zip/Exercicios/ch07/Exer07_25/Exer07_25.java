/*
 * (Oito rainhas: abordagem de força bruta) Nesse exercício você desenvolverá
 * várias abordagens da força bruta para resolver o problema das oito rainhas
 * introduzido no exercício 7.24.
 *
 *      a) Utilize a técnica da força bruta aleatória desenvolvida no exercício
 * 7.23 para resolver o problema das oito rainhas.
 *
 *      b) Utilize uma técnica exaustiva (isto é, tentar todas as combinações
 * possíveis de oito rainhas no tabuleiro) para resolver esse problema.
 *
 *      c) Por que a abordagem da força bruta exaustiva poderia não ser apropriada
 * para resolver o problema do passeio do cavalo ?
 *
 *      d) Compare e contraste as abordagens de força bruta aleatória e da força
 * bruta aleatória.
 */

package ch07.Exer07_25;

/**
 *
 * @author marcio
 */
public class Exer07_25 {

}
