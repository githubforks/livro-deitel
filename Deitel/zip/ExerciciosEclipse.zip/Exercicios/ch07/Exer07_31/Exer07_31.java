/*
 * (Embaralhamento e distribuição de cartas) Utilize os métodos desenvolvidos
 * no Exercício 7.30 para escrever um aplicativo que dirstribui duas mãos de
 * pôque de cinco cartas, avalia cada mão e determina qual é a melhor mão.
 */

package ch07.Exer07_31;

public class Exer07_31 {

}
