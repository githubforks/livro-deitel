/*
 * (Embaralhamento e distribuição de cartas) Modifique o aplicativo desenvolvido
 * no Exercício 7.32 para que ele possa tratar a mão do carteador automaticamente,
 * mas o jogador tenha permissão de decidir que cartas ele quer substituir. O
 * aplicativo então deve avaliar ambas as mãos e determinar quem ganha. Agora
 * utilize esse novo aplicativo para disputar 20 jogos contra o computador. Quem
 * ganha mais jogos, você ou o computador ? Peça para um amigo jogar 20 jogos
 * contra o computador. Quem ganha mais jogos ? Com base nos resultados desses
 * jogos, refine seu aplicativo de pôquer. (Esse também é um problema difícil.)
 * Dispute mais 20 jogos. Seu aplicativo modificado joga melhor ?
 */

package ch07.Exer07_33;

public class Exer07_33 {

}
