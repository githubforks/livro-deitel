/*
 * (Classe Data) Crie uma classe Date com as seguintes capassidades:
 *      a) Gerar saída da data em múltiplos formatos, como
 *          MM/DD/YYYY
 *          June 14, 1992
 *          DDD YYYY
 *      b) Utilizar construtores sobrecarrecados para criar objetos Date
 * inicializados como datas dos formatos na parte (a). No primeiro caso o
 * construtor deve receber três valores inteiros. No segundo caso deve receber
 * uma String e dois valores inteiros. No terceiro caso deve receber dois
 * valores inteiros, o primeiro representando o número de dias no ano. [Dica:
 * Para converter a representação de string do mês em um valor numérico, compare
 * as strings utilozando o método equals. Por exemplo, se s1 e s2 forem strings,
 * a chamada de método s1.equals( s2 ) retonará true se as strings forem
 * idênticas, caso contrário retornará false.]
 */

package ch08.Exer08_16;

/**
 *
 * @author marcio
 */
public class Exer08_16 {

}
