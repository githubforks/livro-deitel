/*
 * (Classe Data e hora) Crie uma classe DateAndTime que combina a classe Time2
 * modificada do Exercício 8.7 e a classe Date modificada do exercício 8.8.
 * Modifique o método incrementHour para chamar o método nextDay se a data/hora
 * for incrementada para o próximo dia. Modifique os métodos toStandardString
 * e toUniversalString para dar saída à data além da hora. Escreva um programa
 * para testar a nova classe DateAndTime. Especificamente, teste o incremento de
 * tempo para o próximo dia.
 */

package ch08.Exer08_13;

public class Exer08_13 {

}
