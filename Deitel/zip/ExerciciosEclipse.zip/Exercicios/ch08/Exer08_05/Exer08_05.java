/*
 * (Modificando a representação interna de dados de uma classe) Seria perfeitamente
 * razoável que a classe Time2 da Figura 8.5 represente a Data/Hora internamente
 * como o número de segundos a partir da meia-noite em vez dos três valores
 * inteiros hour, minute e second. Os clientes poderiam utilizar os mesmos métodos
 * public e obter os mesmos resultados. Modifique a classe Time2 da figura 8.5
 * para implementar Time2 como o número de segundos desde a meia-noite e mostrar
 * que não há alteração visível para os clientes da classe.
 */

package ch08.Exer08_05;

public class Exer08_05 {

}
