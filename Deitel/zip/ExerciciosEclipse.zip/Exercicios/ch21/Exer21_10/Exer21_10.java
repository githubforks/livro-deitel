/*
 * (Chamando a atenção para uma imagem) Se quiser enfatizar uma imagem, você
 * pode colocar uma fileira de lâmpadas simuladas ao torno dela. Você pode fazer
 * com que todas as lampadas acendam ao mesmo tempo ou fazê-las acender e apagar
 * em sequência uma apos a da outra.
 */

package ch21.Exer21_10;

public class Exer21_10 {

}
