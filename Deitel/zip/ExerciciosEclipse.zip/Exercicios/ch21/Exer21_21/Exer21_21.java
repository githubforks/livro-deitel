/*
 * (Gerando e percorrendo o labirinto) Desenvolva um gerador de labirinto e um
 * programa de percurso do labirinto baseado em multimídia com base nos
 * programas de labirinto escritos nos exercícios 15.2-15.22. 0 usuário pode
 * personalizar o labirinto especificando o numero de linhas e colunas e
 * indicando o nivel de dificuldade. Crie uma animação de um ratinho percorrendo
 * o labirinto. Utilize áudio para dramatizar o movimento do ratinho.
 */

package ch21.Exer21_21;

public class Exer21_21 {

}
