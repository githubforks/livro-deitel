/*
 * (Painel de imagens rolantes) Crie um programa Java que role uma imagem ao
 * longo de um painel.
 */

package ch21.Exer21_17;

public class Exer21_17 {

}
