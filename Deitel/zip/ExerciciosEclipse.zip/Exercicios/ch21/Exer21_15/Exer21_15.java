/*
 * (Áudio de fundo) Adicione áudio de fundo em um de seus aplicativos favoritos
 * utilizando o método loop da classe AudioClip para reproduzir o som no fundo
 * enquanto interage com seu aplicativo na maneira normal.
 */

package ch21.Exer21_15;

public class Exer21_15 {

}
