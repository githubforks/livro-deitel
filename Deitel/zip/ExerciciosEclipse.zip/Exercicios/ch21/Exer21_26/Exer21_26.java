/*
 * (Artista) Desenvova um programa Java de arte que forneça a um artista uma
 * grande variedade de recursos de desenho e de utilização de imagens e
 * animações para a criação de uma esposiçãao dinâmica em arte multimídia.
 */

package ch21.Exer21_26;

public class Exer21_26 {

}
