/*
 * (Apagar aleatoriamente uma imagem) Suponha que uma imagem seja exibida em uma
 * Área retangular de tela. Uma maneira de apagar a imagem é simplesmente
 * configurar cada pixel com a mesma cor imediatamente, mas isso resulta em um
 * efeito visual desagradável. Escreva um programa Java que exibe uma imagem e
 * então a apaga utilizando a geração de número aleatório para selecionar pixels
 * individuais a apagar. Depois que a maior parte da imagem tiver sido apagada,
 * apague todos os pixols restantes de uma vez. Você pode desenhar pixels
 * individuais como uma linha que se inicia e termina nas mesmas coordenadas.
 * Você poderia tentar diversas variantes desse problema. Por exemplo, você
 * talvez exiba linhas ou formas aleatoriamente para apagar regiões da tela.
 */

package ch21.Exer21_06;

public class Exer21_06 {

}
