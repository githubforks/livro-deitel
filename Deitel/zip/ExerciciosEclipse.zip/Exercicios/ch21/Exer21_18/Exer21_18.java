/*
 * (Relógio analógico) Crie um programa Java que exibe um relógio analógico com
 * ponteiros de hora, minuto e segundo que se mvem apropriadamente à medida que
 * o tempo passa.
 */

package ch21.Exer21_18;

public class Exer21_18 {

}
