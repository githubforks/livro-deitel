/*
 * (Colorindo fotografas e imagens P&B) Crie um programa em Java que permita
 * colorir uma fotografia em preto-e-branco. Forneça uma paleta de cores para
 * selecionar cores. Seu programa deve permitir a aplicação de diferentes cores
 * a diferentes regiões da imagem.
 */

package ch21.Exer21_34;

public class Exer21_34 {

}
