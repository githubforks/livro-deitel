/*
 * (Designer de fogos te artifício) Crie um programa em Java que poderia ser
 * utilizado para criar um show de fogos de artifício. Crie uma variedade de
 * demonstrações de fogos de artificio. Então orquestre a queima dos fogos de
 * artiócio para obter um efeito máximo.
 */

package ch21.Exer21_27;

public class Exer21_27 {

}
