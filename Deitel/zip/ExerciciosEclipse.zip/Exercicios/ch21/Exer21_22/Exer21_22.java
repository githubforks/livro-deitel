/*
 * (Caça-níqueis) Desenvolva uma simulação de multimídia de um caça-níqueis com
 * três rodas giratórias. Coloque imagens de várias frutas e símbolos em cada
 * roda. Utilize a geração de números aleatórios para simular o giro e a parada
 * de cada roda em um símbolo.
 */

package ch21.Exer21_22;

public class Exer21_22 {

}
