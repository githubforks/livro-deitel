/*
 * (Poemas) Modifique o programa feito no Exercicio 10.10 para cantar os poemas
 * que seu programa criou.
 */

package ch21.Exer21_13;

public class Exer21_13 {

}
