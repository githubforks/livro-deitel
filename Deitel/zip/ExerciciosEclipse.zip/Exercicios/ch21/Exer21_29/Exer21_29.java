/*
 * (Palavras cruzadas) Palavras cruzadas estão entre os passatempos mais
 * populares. Desenvolva um programa de palavras cruzadas baseado em multimidia.
 * Seu programa deve permitir que o jogador insira e retire facilmente as
 * palavras. Associe seu programa a um grande dicionário computadorizado. O
 * programa também deve ser capaz de sugerir as palavras com base nas letras já
 * preenchidas. Forneça outro recurso que facilite o trabalho do entusiasta de
 * palavras cruzadas.
 */

package ch21.Exer21_29;

public class Exer21_29 {

}
