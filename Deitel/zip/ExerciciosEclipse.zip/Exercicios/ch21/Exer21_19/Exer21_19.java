/*
 * (Áudio dinâmico e caleidoscópio gráfico) Desenvolva um programa de
 * caleidoscópio que exiba imagens gráficas refletidas para simular um brinquedo
 * infantil bastante conhecido. Incorpore os efeitos de áudio que 'reflitam' as
 * imagens gráficas dinamicamente mutantes de seu programa.
 */

package ch21.Exer21_19;

public class Exer21_19 {

}
