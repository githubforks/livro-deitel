/*
 * (Simulador Simpletron baseado em multimidia) Modifique o simulador Simpletron
 * desenvolvido nos exercícios dos capitulas anteriores (exercícios 7.34-7.36 e
 * 17.26-17.30) para incluir recursos multimídia. Adicione sons de computador
 * para indicar que o Simpletron está executando instruções. Adicione um som de
 * vidro quebrando quando um erro fatal ocorrer. Utilize luzes intermitentes
 * para indicar as células de memória ou os registros que estão sendo
 * manipulados atualmente. Utilize outras técnicas de multimídia conforme sua
 * conveniência para tornar seu simulados Simpletron mais valioso como uma
 * ferramenta educacional para seus usuários.
 */

package ch21.Exer21_35;

public class Exer21_35 {

}
