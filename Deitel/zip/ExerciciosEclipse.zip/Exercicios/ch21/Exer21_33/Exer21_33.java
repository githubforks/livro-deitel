/*
 * (Rotação de imagens) Crie um programa Java que permita rotacionar uma imagem
 * por vários graus (até um máximo de 360 graus). O programa deve permitir que
 * você especifique se quer girar a imagem continuamente, além de permitir
 * ajustar dinâmicamente a velocidade da rotação.
 */

package ch21.Exer21_33;

public class Exer21_33 {

}
