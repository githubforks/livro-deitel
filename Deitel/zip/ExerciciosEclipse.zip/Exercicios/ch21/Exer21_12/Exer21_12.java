/*
 * (Animação) Crie um programa de animação Java de uso geral. Você deve permitir
 * ao usuário especificar a seqüência de quadros a ser exibida, a velocidade em
 * que as imagens são exibidas, os áudios a ser reproduzidos enquanto a animação
 * estiver sendo executada e assim por diante.
 */

package ch21.Exer21_12;

public class Exer21_12 {

}
