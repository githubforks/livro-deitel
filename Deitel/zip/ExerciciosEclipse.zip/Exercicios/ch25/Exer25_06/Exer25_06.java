/*
 * Modifique o Exercicio 25.5 para realizar as seguintes tarefas:
 *      a) Aumente 10% do salário base de todos os empregados comissionados com
 *         salário base.
 *      b) Se o aniversário do empregado cair no mês atual, adicione um bonus de
 *         $ 100.
 *      c) Para todos os empregados comissionados com vendas brutas acima de
 *         $ 10.000 adicione um bónus de $ 100.
 */

package ch25.Exer25_06;

public class Exer25_06 {

}
