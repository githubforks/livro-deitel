/*
 * Escreva um aplicativo que exiba eventos a medidas que eles ocorrem em um
 * JTextArea. Forneça um JComboBox com um mínimo de quatro itens. O usuário deve
 * ser capaz de escolher um evento para monitorar a partir do JComboBox. Quando
 * esse evento particular ocorrer, exiba informações sobre o evento no JTextArea.
 * Utilize o método toString no objeto de evento para convertê-lo em uma
 * representação de string.
 */

package ch11.Exer11_14;

/**
 *
 * @author marcio
 */
public class Exer11_14 {

}
