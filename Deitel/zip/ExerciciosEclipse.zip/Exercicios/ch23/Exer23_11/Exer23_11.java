/*
 * Modifique o programa no Exercicio 23.10 para adicionar sombras. A medida que
 * uma bola se move, desenhe uma oval sólida preta na parte inferior do JPanel.
 * Você pode considerar a adicionar um efeito 3-D aumentando ou diminuindo o
 * tamanho de cada bola quando ela atingir a borda do JPanel.
 */

package ch23.Exer23_11;

public class Exer23_11 {

}
