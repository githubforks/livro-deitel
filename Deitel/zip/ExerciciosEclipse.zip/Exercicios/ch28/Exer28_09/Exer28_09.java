/*
 * (Arredondando números) Escreva um programa que imprima o valor 100,453627
 * arredondado para o dígito mais próxido, décimo, centésimo, milésimo e décimo
 * de milésimo.
 */

package ch28.Exer28_09;

public class Exer28_09 {

}
