/*
 * Escreva um programa que insira uma palavra a partir do teclado e determina o
 * comprimento da palavra. Imprima a palavra utilizando um tamanho duas vezes
 * maior que o comprimento da largura de campo.
 */

package ch28.Exer28_10;

public class Exer28_10 {

}
