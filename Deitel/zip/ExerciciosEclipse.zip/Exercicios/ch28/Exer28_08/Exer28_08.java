/*
 * Escreva um programa para testar os resultados da impressão do vator inteiro
 * 12345 e do valor de ponto flutuante 1,2345 em vários tamanhos de campos.
 */

package ch28.Exer28_08;

public class Exer28_08 {

}
