/*
 * (Imprimindo datas e horas) Escreva um programa que imprima datas e horas nos
 * formatos a seguir:
 *      GMT ~ 05:00 04/30/04 09:55:09 AM
 *      GMT ~ 05:00 April 30 2004 09:55:09
 *      2004-04-30 day-of-the-month:30
 *      2004-04-30 day-of-the-year:121
 *      Fri Apr 30 09:55:09 GMT~05:00 2004
 * [Nota: Dependendo da sua localização, talvez haja outros fusos horários além
 * do GMT~05:00.]
 */

package ch28.Exer28_07;

public class Exer28_07 {

}
