/*
 * Os computadores estão desenpenhando um crescente papel na educação. Ecreva
 * um programa que ajudará um estudante do ensino fundamental a aprender
 * multiplicação. Utilize o método Random para produzir dois inteiros positivos
 * de um algarismo. O programa então deve fazer ao usuário uma pergunta, como
 *
 *          How much is 6 times 7?
 * 
 * O aluno insere então a resposta. Em seguida, o programa verifica a resposta
 * do aluno, se estiver correta, exiba a mensagem "Very good!" e faça outra
 * pergunta de multiplicação, se a resposta estiver errada, exiba a mensagem
 * "No. Please try again!" e deixe que o estudante tente a mesma pergunta
 * repetidamente até por fim responder corretamente. Um método separado deve ser
 * utilizado para gerar cada nova pergunta. Esse método deve ser chamado uma vez
 * quando a aplicação inicia a execução e toda vez quando o usuário responde
 * corretamente.
 */

package ch06.Exer06_30;

public class Exer06_30
{
	public static void main( String args[] )
	{
		
	}
}
