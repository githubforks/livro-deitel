/*
 * Escreva um aplicativo que teste se o exemplos de chamadas de método da classe
 * Math mostrada na figura 6.2 realmente produz os resultados esperados.
 */

package ch06.Exer06_03;

public class Exer06_03
{
	public static void main(String[] args)
	{
		
	}
}
