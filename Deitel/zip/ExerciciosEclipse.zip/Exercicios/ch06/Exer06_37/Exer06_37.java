/*
 * Modifique o programa de jogo de dados da figura 6.9 para permitir apostas.
 * Inicialize a variável bankBalance com $ 1.000. Peça ao jogador para inserir
 * um wager (uma aposta). Verifique se o wager é menor ou igual a bankBalance e,
 * se não o for, faça o usuário reinserir o wager até um wager válido inserido.
 * Depois que um wager correto foi inserido, execute um jogo de dados. Se o
 * jogador ganhar, aumente o bankBalance poe wager e exiba o novo bankBalance.
 * Se o jogador perder, diminua o bankBalance por wager, exiba o novo bank
 * balance, verifique se bankBalance tornou-se zero e, se tiver ocorrido, exiba
 * a mensagem "Sorry. You busted." ["Desculpe, mas você faliu."]. Enquanto o
 * jogo se desenvolve, exiba várias mensagens para criar uma 'conversa', como
 * "Oh, you're going for brokw, huh?" ["Oh, parece que você vai quebrar, hein?"]
 * ou "Aw, c'mon, take a chance" ["Ah, vamos lá, dê uma chance para sua sorte!"]
 * ou "You're up big. No's the time to cash in your chips!" [Você está montado
 * na grana. Agora é hora de trocar essas fichas e embolsar o dinheiro!"].
 * Implemente a 'conversa' como um método separado que escolhe aleatóriamente a
 * string a exibir.
 */

package ch06.Exer06_37;

public class Exer06_37 {

}
