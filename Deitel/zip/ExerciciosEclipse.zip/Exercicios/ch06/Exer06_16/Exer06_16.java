/*
 * Escreva um método multiple que determina um par de inteiros se o segundo
 * inteiro for múltiplo do primeiro. O método deve aceitar dois argumentos
 * inteiros e retornar true se o segundo for múltiplo do primeiro e false se o
 * contrário. Incorpore esse método a um aplicativo que insere uma série de
 * pares inteiros (um par por vez) e determina se o segundo valor em cada par é
 * múltiplo do primeiro.
 */

package ch06.Exer06_16;

public class Exer06_16
{
	public static void main ( String args[] )
	{
		
	}
}
