/*
 * Escreva um método qualityPoints que insere a média de um aluno e retorna 4
 * se a média estiver entre 90 e 100, 3 se a média estiver entre 80 e 89, 2 se
 * a média estiver entre 70 e 79, 1 se se a média estiver entre 60 e 69, e 0 se
 * a média for mais baixa que 60. Incorpore o método a um aplicativo que lê um
 * valor do usuário e exibe o resultado.
 */

package ch06.Exer06_28;

public class Exer06_28 {
	public static void main ( String args[] )
	{
		
	}
}
