/*
 * Muitos programas escritos com herança podem ser escritos com composição e
 * vice-versa. Reescreva a classe BasePlusComissionEmployee4 (Figura 9.13) da
 * hierarquia CommissionEmployee3-BasePlusCommissioEmployee4 para utilizar
 * composição em vez de herança. Depois de fazer isso, avalie os méritos
 * relativos das duas abordagens para os problemas CommissionEmployee3 e
 * BasePlusCommissionEmployee4, bem como para programas orientados a objetos em
 * geral. Que abordagem é mais natural? Por quê?
 */

package ch09.Exer09_03;

public class Exer09_03 {

}
