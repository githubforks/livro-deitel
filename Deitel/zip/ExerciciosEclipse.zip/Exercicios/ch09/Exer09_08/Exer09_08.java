/*
 * Escreva uma hierarquia para a classe Quadrilátero, Trapézio, Paralelogramo,
 * Retângulo e quadrado. Utilize Quadrilateral como a superclasse da hierarquia.
 * Faça a hierarquia o mais profunda (isto é, com muitos níveis) possível.
 * Especifique as variáveis de instância e os métodos para cada classe. As
 * variáveis de instância private de Quadrilateral devem ser os pares de
 * coordenadas x-y para os quatro pontos que delimitan o Quadrilátero. Escreva
 * um programa que inicia objetos de suas classes e gera saída da área de cada
 * objeto (exceto Quadrilátero).
 */

package ch09.Exer09_08;

public class Exer09_08 {

}
