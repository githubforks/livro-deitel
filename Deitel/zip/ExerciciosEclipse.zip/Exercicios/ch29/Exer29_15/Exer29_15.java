/*
 * Escreva um aplicativo que lê uma linha de texto, tokeniza essa linha
 * utilizando caracteres de espaço em branco como delimitadores e gera a saída
 * apenas daquelas palavras que terminem com as letras "ED".
 */

package ch29.Exer29_15;

public class Exer29_15 {

}
