/*
 * (Limericks) Um limericks é um poema humoristico de cinco versos em que a
 * primeira e a segunda linha rimam com a quinta, e a terceira linha rima com a
 * quarta. Utilizando técnicas semelhantes àquelas desenvolvidas no Exercício
 * 29.5, escreva um aplicativo Java que produz limericks aleatórios. Polir esse
 * aplicativo para produzir bons limericks é um problema desafiador, mas o
 * resultado vale o esforço!
 */

package ch29.Exer29_06;

public class Exer29_06 {

}
