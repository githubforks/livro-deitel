/*
 * Escreva um aplicativo que insira uma linha de texto, tokenize a linha com um
 * objeto da classe StringTokenizer e envie os tokens para a saída na ordem
 * inversa. Utilize caracteres de espaço em branco como delimitadores.
 */

package ch29.Exer29_09;

public class Exer29_09 {

}
