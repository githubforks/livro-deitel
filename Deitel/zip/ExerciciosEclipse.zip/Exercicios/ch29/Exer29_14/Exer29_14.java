/*
 * Escreva um aplicativo que leia uma linha de texto, tokenize essa linha
 * utilizando caractere de espaço em branco como delimitadores e gere a saída
 * apenas daquelas palavras que iniciam com a letra "b".
 */

package ch29.Exer29_14;

public class Exer29_14 {

}
