/*
 * Escreva um aplicativo que utilize o método String regionMatches para comparar
 * duas entradas de strings pelo usuário. O aplicativo deve inserir o número de
 * caracteres que sará comparado e o índice inicial da comparação. O aplicativo
 * deve declarar se as strings são iguais. Ignore a distinção entre maiúsculos e
 * minúsculas dos caracteres ao realizar a comparação.
 */

package ch29.Exer29_04;

public class Exer29_04 {

}
