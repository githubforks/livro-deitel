/*
 * Escreva umaplicativo que insira uma linhade texto e um caractere de pesquisa
 * e utilize o método String indexOf para determinar o número de ocorrências do
 *  caractere no texto.
 */

package ch29.Exer29_12;

public class Exer29_12 {

}
