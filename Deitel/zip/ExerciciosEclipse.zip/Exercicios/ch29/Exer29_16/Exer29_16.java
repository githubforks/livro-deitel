/*
 * Escreva um aplicativo que insira um código de inteiro para um caractere e
 * exiba o caractere correspondente. Modifique esse aplicativo de modo que ele
 * gere todos os possiveis códigos de três digitos no intervalo de 000 a 255 e
 * tente imprimir os caracteres correspondentes.
 */

package ch29.Exer29_16;

public class Exer29_16 {

}
