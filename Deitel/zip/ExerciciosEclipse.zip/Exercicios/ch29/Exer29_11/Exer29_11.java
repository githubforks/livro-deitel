/*
 * Escreva um aplicativo que insira uma linha de texto e gere duas vezes a saída
 * do texto - uma vez em letras maiúsculas e uma vez, em minúsculas.
 */

package ch29.Exer29_11;

public class Exer29_11 {

}
