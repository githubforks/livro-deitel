/*
 * Escreva um aplicativo que utilize o método String compareTo para comparar
 * duas entradas de strings pelo usuário. Crie uma saída informando se a
 * primeira string é menor que, igual a ou maior que a segunda.
 */

package ch29.Exer29_03;

public class Exer29_03 {

}
