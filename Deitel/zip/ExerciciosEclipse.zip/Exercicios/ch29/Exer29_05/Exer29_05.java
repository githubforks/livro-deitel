/*
 * Escreva um aplicativo que utilize geração de números aleatórios para criar
 * frases. Utilize quatro arrays de strings chamados anticle, noun, verb e
 * preposition. Crie uma frase selecionando uma palavra aleatoriamente de cada
 * array na seguinte ordem: article, noun, verb, preposition, article e noun. A
 * medida que cada palavra for selecionada, concatene-a as primeiras palavras na
 * frase. As palavras devem ser separadas por espaços. Quando a frase final for
 * enviada para saída, ela deve iniciar com uma letra maiúscula e terminar com
 * um ponto. O aplicativo deve gerar 20 frases e enviar sua saída para uma área
 * de texto.
 *      O array de artigos deve conter os artigos "the", "a", "one", "some" e
 * "any"; o array de substantivos deve conter os substantivos "boy", "girl",
 * "dog", "town" e "car"; o array de verbos deve conter os verbos "drove",
 * "jumped", "ran", "walked" e "skipped'; o array de preposiçoes deve conter as
 * preposições "to", "from", "over", "under" e "on".
 *      Depois que o aplicativo anterior for escrito, modifique-o para produzir
 * uma breve história que consista em várias dessas frases. (E que tal um
 * escritor de teses aleatório?)
 */

package ch29.Exer29_05;

public class Exer29_05 {

}
