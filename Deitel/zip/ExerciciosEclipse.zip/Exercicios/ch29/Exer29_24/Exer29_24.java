/*
 * (Aplicativo de conversão Métrica) Escreva um aplicativo que auxiliará o
 * usuário com vonversões métricas. Seu aplicativo deve permitir que o usuário
 * especifique os nomes das unidades como strings (isto é, centímetros, litros,
 * gramas etc. para o sistema métrico e polegadas, quartos, libras otc. para o
 * sistema inglês) e deve responder a perguntas simples como
 *
 *      "How many inches are in 2 meters?"
 *      "How many liters are in 10 quarts?"
 *
 * Seu aplicativo deve reconhecer conversões inválidas. Por exemplo, a pergunta
 *
 *      "How many feet are in 5 kilograms?"
 *
 * não é significativo porque "feet" é uma unidade de comprimento, enquanto
 * "kilograms" é uma unidade do massa.
 */

package ch29.Exer29_24;

public class Exer29_24 {

}
