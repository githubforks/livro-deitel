/*
 * Utilize uma HashMap para criar uma classe reutilizável a fim de escolher uma
 * das 13 cores predefinidas na classe Color. Os nomes das cores devem ser
 * utilizados como chaves, e os objetos Color predefinidos devem ser utilizados
 * como valores. Coloque essa classe em um pacote que pode ser importado em
 * qualquer programa Java, Utilize sua nova classe em um aplicativo que permite
 * ao usuário selecionar uma cor e desenhar uma forma nessa cor.
 */

package ch19.Exer19_15;

public class Exer19_15 {

}
