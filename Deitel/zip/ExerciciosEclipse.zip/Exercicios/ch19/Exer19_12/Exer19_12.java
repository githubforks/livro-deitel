/*
 * Reescreva as linhas 17-26 na Figura 19.4 para que sejam mais concisas
 * utilizando o método asList e o construtor LinkedList que aceita um argumento
 * Colection.
 */

package ch19.Exer19_12;

public class Exer19_12 {

}
