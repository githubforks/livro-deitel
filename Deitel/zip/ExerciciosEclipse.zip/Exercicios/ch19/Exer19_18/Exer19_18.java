/*
 * Reescreva sua solução do Exercicio 17.9 para utilizar uma coleção LinkedList.
 */

package ch19.Exer19_18;

public class Exer19_18 {

}
