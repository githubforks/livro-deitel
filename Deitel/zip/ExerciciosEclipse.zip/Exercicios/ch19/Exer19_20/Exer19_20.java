/*
 * Escreva um programa que utilize um StringTokenizer para separar em tokens uma
 * linha de texto inserido pelo usuário e que coloque cada token em um TreeSet.
 * Imprima os elementos do TreeSet. [Nota: isso deve fazer com que os elementos
 * sejam impressos na ordem de classificaçã ascendente.]
 */

package ch19.Exer19_20;

public class Exer19_20 {

}
