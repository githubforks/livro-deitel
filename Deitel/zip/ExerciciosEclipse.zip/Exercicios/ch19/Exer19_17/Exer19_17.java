/*
 * Reescreva sua solução do Exercício 17.8 para utilizar uma coleção LinkedList.
 */

package ch19.Exer19_17;

public class Exer19_17 {

}
