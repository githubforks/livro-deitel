/*
 * (Imprimir rerursivamente uma lista de trás para frente) Escreva um método
 * printListBackward que recursivamente gera saída dos itens em objeto lista
 * vinculada na ordem inversa. Escreva um programa de teste que cria uma lista
 * classificada de inteiros e imprime a lista em ordem inversa.
 */

package ch17.Exer17_20;

public class Exer17_20 {

}
