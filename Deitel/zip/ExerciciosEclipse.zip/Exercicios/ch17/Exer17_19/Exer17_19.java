/*
 * Escreva um método depth que recebe uma árvore binária e determina quantos
 * níveis ela tem.
 */

package ch17.Exer17_19;

public class Exer17_19 {

}
