/*
 * (Pesquisar recursivamente uma lista) Escreva um método searchList que
 * pesquise recursivamente um valor espocificado em um objeto lista vinculada. O
 * método searchList deve retornar uma referência ao valor se ele for
 * localizado; caso contrário, deve retornar null. Utilize seu método em um
 * programa de teste que cria uma lista de inteiros. O programa deve solicitar
 * ao usuário um valor para localizar na lista.
 */

package ch17.Exer17_21;

public class Exer17_21 {

}
