/*
 * Escreva um aplicativo que utilize somente as instruções de saída
 *		System.out.print("*");
 *		System.out.print(" ");
 *		System.out.println();
 * para seguir o padrão de tabuleiro de damas a seguir. Observe que uma chamada
 * System.out.println sem argumentos faz com que o programa gere saída de um único caractere
 * de nova linha. [Dica: As instruções de repetição são requeridas.]
 */

package ch04.Exer04_32;

public class Exer04_32
{
	public static void main(String[] args)
	{
		
	}
}
