package ch04.Exer04_24;

public class AnalysisTest 
{
	public static void main( String args[] ) 
	{
		
	}
}