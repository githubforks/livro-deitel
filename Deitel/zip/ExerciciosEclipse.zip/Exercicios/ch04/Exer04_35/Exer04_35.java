/*
 * Escreva um aplicativo que leia três valores diferentes de zero inseridos pelo usuário e
 * determine e imprima se eles poderiam representar os lados de um triângulo.
 * 
 * 
 * 	[Nota: Classe Compara baseada na descrição em: http://pt.wikipedia.org/wiki/Tri%C3%A2ngulo#Condi.C3.A7.C3.A3o_de_exist.C3.AAncia_de_um_tri.C3.A2ngulo ]
 */

package ch04.Exer04_35;

public class Exer04_35
{
	public static void main(String[] args)
	{
		
	}
}
