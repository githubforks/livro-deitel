/*
 * Utilizando uma abordagem semelhante àquela do Exercício 4.21, encontre os dois maiores
 * valores entre os 10 valores inseridos. [Nota: Você só pode inserir cada número uma vez.]
 */

package ch04.Exer04_23;

public class Exer04_23
{
	public static void main(String[] args)
	{

	}
}
