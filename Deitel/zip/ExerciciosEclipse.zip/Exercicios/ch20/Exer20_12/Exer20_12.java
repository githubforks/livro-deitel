/*
 * Escreva um applet que permite ao usuário inserir os quatro argumentos
 * requeridos pelo método drawOval, então desenhe uma os utilizando os quatro
 * valores de entrada.
 */

package ch20.Exer20_12;

public class Exer20_12 {

}
