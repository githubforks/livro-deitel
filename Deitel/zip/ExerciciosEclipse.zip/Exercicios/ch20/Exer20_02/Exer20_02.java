/*
 * Escreva um applet que pede para o usuário inserir dois números de ponto
 * flutuante, obtém do usuário os dois números e desenha sua soma, produto
 * (multiplicação), diferença e quociente (divisão). Utilize as técnicas
 * mostradas na Figura 20.10.
 */

package ch20.Exer20_02;

public class Exer20_02 {

}
