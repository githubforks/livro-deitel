/*
 * Escreva um applet que lê cinco inteiros, determina e imprime o maior e o
 * menor inteiro no grupo. Ecreva um aplet que lê dois números de ponto
 * flutuante e determina e imprime se o primeiro é um múltiplo do segundo.
 */

package ch20.Exer20_06;

public class Exer20_06 {

}
