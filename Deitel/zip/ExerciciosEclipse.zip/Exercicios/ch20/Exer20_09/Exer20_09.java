/*
 * Escreva um applet que permite ao usuário inserir os quatro valores para os
 * argumentos requeridos pelo método drawRect, então desenhes régulo utilizando
 * os quatro valores de entrada.
 */

package ch20.Exer20_09;

public class Exer20_09 {

}
