/*
 * Escreva um applet que pede para o usuário inserir três números de ponto
 * flutuante e exibe a soma, média, produto, maior e menor desses números como
 * strings no applet. Utilize as técnicas mostradas na Figura 20.10.
 */

package ch20.Exer20_04;

public class Exer20_04 {

}
