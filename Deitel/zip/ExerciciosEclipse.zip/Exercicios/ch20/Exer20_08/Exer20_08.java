/*
 * Escreva um applet que desenha retangulos de diferentes tamanhos e localizada.
 */

package ch20.Exer20_08;

public class Exer20_08 {

}
