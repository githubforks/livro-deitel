/*
 * (Desenhando cubos) Escreva um aplicativo que desenha um cubo. Utilize a
 * classe GeneralPath e o método draw da classe Graphics2D.
 */

package ch12.Exer12_16;

public class Exer12_16 {

}
