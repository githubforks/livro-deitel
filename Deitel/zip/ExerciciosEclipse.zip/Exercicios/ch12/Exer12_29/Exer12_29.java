/*
 * (Cores aleatórias) Modifique o Exercício 12.28 para desenhar cada uma das 20
 * formas com dimensões aleatórias em uma cor selecionada aleatoriamente.
 * Utilize todos os 13 objetos Color predefinidos em um array de Colors.
 */

package ch12.Exer12_29;

public class Exer12_29 {

}
