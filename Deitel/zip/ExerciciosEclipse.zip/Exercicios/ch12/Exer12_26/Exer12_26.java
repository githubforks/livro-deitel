/*
 * (Desenhando espirais) Escreva um aplicativo que utiliza o método Graphics
 * drawPolyline para desenhar uma espiral semelhante àquela mostrada na Figura
 * 12.33.
 */

package ch12.Exer12_26;

public class Exer12_26 {

}
