/*
 * (Círculos utilizando a classe Ellipse2D.Double) Escreva um aplicativo que
 * solicita ao usuário inserir o raio de um círculo como um número de ponto
 * flutuante e desenha o círculo, bem como os valores do diâmetro do círculo,
 * circunferência e área. Utilize o valor 3.14159 para π. [Nota: Você também
 * pode utilizar a constante Math.PI predefinida para o valor de π. Essa
 * constante é mais precisa que o valor 3.14159. A classe Math é declarada no
 * pacote java.lang, então você não precisa importá-la.] Utilize as seguintes
 * fórmulas (r é o raio):
 *      diâmetro = 2r
 *      circunferência = 2πr
 *      área = πr^2
 *      Também se deve solicitar ao usuário um conjunto de coordenadas além do
 * raio. Então desenhe o círculo e exiba o diâmetro, a circunferência e a área
 * do círculo utilizando um objeto Ellipse2D.Double para representar o círculo e
 * o método draw da classe Graphics2D para exibi-lo.
 */

package ch12.Exer12_17;

public class Exer12_17 {

}
