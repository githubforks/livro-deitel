/*
 * (A tartaruga e a lebre) Crie uma versão gráfica da simulação da tartaruga e a
 * lebre (Exercício 7.28). Simule a montanha desenhando um arco que se estende
 * do canto inferior esquerdo ao canto superior direito da janela. A lebre e a
 * tartaruga devem correr subindo a montanha. Implemente a saída gráfica para
 * imprimir a tartaruga e a lebre no arco a cada movimento. [Nota: Estenda o
 * percurso da corrida de 70 para 300 a fim de permitir uma área gráfica maior.]
 */

package ch12.Exer12_25;

public class Exer12_25 {

}
