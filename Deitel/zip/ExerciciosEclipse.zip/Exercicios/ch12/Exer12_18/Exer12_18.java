/*
 * (Protetor de tela) Escreva um aplicativo que simula um protetor de tela. O
 * aplicativo deve desenhar linhas aleatoriamente utilizando o método drawLine
 * da classe Graphics. Depois de desenhar 100 linhas, o aplicativo deve se
 * auto-redefinir e começar a desenhar as linhas de novo. Para permitir que o
 * programa desenhe continuamente, coloque uma chamada de rapaint como a última
 * linha no método paintComponent. Você notou algum problema com isso em seu
 * sistema?
 */

package ch12.Exer12_18;

public class Exer12_18 {

}
