/*
 * (Desenhando tetraedros) Escreva um aplicativo que desenha um tetraedro (uma
 * pirâmide). Utilize a classe GeneralPath e o método draw da classe Graphics2D.
 */

package ch12.Exer12_15;

public class Exer12_15 {

}
