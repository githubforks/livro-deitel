/*
 * (Protetor de tela utilizando a API do Java 2D) Modifique sua solução do
 * Exercício 12.21 para utilizar as classes e as capacidades de desenho da API
 * do Java 2D. Desenhe formas como retângulos e ovais, com gradientes gerados
 * aleatoriamente. Uilize a classe GradientPain para gerar o gradiente.
 */

package ch12.Exer12_22;

public class Exer12_22 {

}
