/*
 * (Tic-Tac-Toe 3-D multiencadeado) Modifique o programar Tic-Tac-Toe
 * cliente/servidor multiencadeado para implementar uma versão tridimensional do
 * jogo 4 por 4 por 4. Implemente o aplicativo servidor para mediar entre os
 * dois clientes. Exiba o tabuleiro tridimensional como quatro tabuleiros
 * contendo quatro linhas e quatro colunas cada um. Se você for ambicioso,
 * experimente as seguintes modificações:
 *      a) Desenhe o tabuleiro de uma maneira tridimensional.
 *      b) Permita ao servidor testar se há um ganhador, um perdedor ou um
 *         empate. Cuidado! Há muitas possíveis maneiras de ganhar em um
 *         tabuleiro 4 por 4 por 4!
 */

package ch24.Exer24_22;

public class Exer24_22 {

}
