/*
 * (Jogo de xadrez) Desenvolva um programa de jogo de xadrez modelado de acordo
 * com o programa de damas no Exercício 24.17.
 */

package ch24.Exer24_18;

public class Exer24_18 {

}
