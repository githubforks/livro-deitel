/*
 * (Jogo de cartas "vinte e um") Desenvolva um programa de jogo de cartas do
 * tipo "vinte e um" em que o aplicativo servidor distribui as cartas para cada
 * um dos applets-cliente. O servidor deve distribuir as cartas adicionais (de
 * acordo com as regras do jogo) para cada jogador quando solicitado.
 */

package ch24.Exer24_19;

public class Exer24_19 {

}
