/*
 * (Jogo de damas) No texto, apresentamos um programa de jogo-da-velha
 * controlado por um servidor com múltiplas threads. Desenvolva um programa de
 * damas modelado com base no programa Tic-Tac-Toe (jogo-da-velha). Os dois
 * usuários devem fazer movimentos alternados. Seu programa deve mediar os
 * movimentos dos jogadores, determinando de quem é a vez e permitindo apenas
 * movimentos válidos. Os próprios jogadores determinarão quando 0 jogo acabou.
 */

package ch24.Exer24_17;

public class Exer24_17 {

}
