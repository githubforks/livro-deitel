/*
 * Escreva um programa que exibe um círculo de tamanho aleatório e calcula e
 * exibe área, raio, diâmetro e circunferência. Utilize as seguintes equações:
 * diâmetro = 2 x raio, area = π x raio², circunferência = 2 x π x raio.
 * Utilize a constante Mate.PI para pi (PI). Todos os desenhos devem ser feitos
 * em uma subclasse de JPanel e os resultados dos cálculos devem ser exibidos em
 * um JTextArea de leitura (read-only).
 */

package ch22.Exer22_07;

public class Exer22_07 {

}
