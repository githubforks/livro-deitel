/*
 * Escreva ump rograma que utiliza o método paintComponent para desenhar o
 * valor atual de um JSlider em uma subclasse de JPanel. Além disso, forneça um
 * JTextField em que um valor específico possa ser inserido. O JTextField deve
 * exibir o valor atual do JSilider todas as vezes. Um JLabel deve ser utilizado
 * para identificar o JTextField. Os métodos JSilider setValue e getVal devem
 * ser utilizados. [Nota: O método setValue é um método public que não retorna
 * um valor e aceita um argumento do tipo inteiro, o valor JSlider, que
 * determina a posição da caixa de rolagem.]
 */

package ch22.Exer22_10;

public class Exer22_10 {

}
