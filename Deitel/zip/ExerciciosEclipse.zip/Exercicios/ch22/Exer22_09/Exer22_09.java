/*
 * Explore os efeitos de variar os valores weightx e weighty do programa na
 * Figura 22.21. O que acontece quando um slot tem um peso diferente de zero,
 * mas não pode ocupar toda a áres (isto é, o valor fill não e BOTH)?
 */

package ch22.Exer22_09;

public class Exer22_09 {

}
