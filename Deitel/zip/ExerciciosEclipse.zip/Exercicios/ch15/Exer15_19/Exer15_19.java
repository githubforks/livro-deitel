/*
 * (Fractais) Repita o padrão de fractal na Seção 19.5 para formar uma estrela.
 * Inicie com cinco linhas, em vez de uma, onde cada linha é uma ponta diferente
 * da estrela. Aplique o padrão 'fractal de Lo' a cada ponta da estrela.
 */

package ch15.Exer15_19;

public class Exer15_19 {

}
