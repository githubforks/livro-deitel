/*
 * (Visualizando a recursão) É interessante observar a recursção 'em ação'.
 * Modifique o método fatorial da Figura 15.3 para imprimir sua variável local e
 * o parâmetro de chamada recursiva. Para cada chamada recursiva, exiba as
 * saídas em uma linha separada e adicione um nível de recuo. Faça o melhor que
 * você puder para tornar a saída limpa, interessante e significativa. Seu
 * objetivo aqui é implementar um formato de saída que facilite o entendimento
 * recursão. Você pode querer adicionar essas capacidades de exibição a outros
 * exemplos de recursão e a exercíciospor todo o texto.
 */

package ch15.Exer15_10;

public class Exer15_10 {

}
