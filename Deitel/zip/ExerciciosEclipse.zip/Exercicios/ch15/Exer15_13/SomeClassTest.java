// Exercício 15.13: SomeClassTest.java
package ch15.Exer15_13;

public class SomeClassTest {
/*    public static void main(String args[]) {
        SomeClass someClassObject = new SomeClass();

        int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        String results =
                someClassObject.someMethod(array, 0);

        System.out.println(results);
    } // fim de main
*/
} // fim da classe SomeClassTest 
