// Exercício 15.13: SomeClass.java
package ch15.Exer15_13;

public class SomeClass {
/*    public String someMethod(int array2[], int x, String output) {
        if (x < array2.length)
            return String.format("%s%d ", someMethod(array2, x + 1), array2[ x ]);
        else
            return "";
    } // fim do método someMethod
*/
} // fim da classe SomeClass 
