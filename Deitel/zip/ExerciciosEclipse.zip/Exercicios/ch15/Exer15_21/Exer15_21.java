/*
 * (Gerando labirintos aleatoriamente) Escreva um método mazeGenerator que
 * recebe como um argumento um array de 12 caracteres bidimensional e produza
 * aleatoriamente um labirinto. O método tembém deve fornecer as posições
 * inicial e final do labirinto. Teste seu método mazeTraversal do Exercício
 * 15.20 utilizando vários labirintos gerados aleatóriamente.
 */

package ch15.Exer15_21;

public class Exer15_21 {

}
