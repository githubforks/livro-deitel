/*
 * (Modificação do sistema de falha de pagamento) Modifique o sistema de folha
 * de pagamento das figuras 10.4-10.9 para incluir uma subclasse PieceWorker
 * adicional de Employee que representa um funcionário cujo pagamento está
 * baseado no número de peças de mercadorias produzido. A classe PieceWorker
 * deve conter variáveis de instância wage private (para armazenar o salário do
 * funcionário por peça) e pieces (para armazenar o número de peças produzido).
 * Forneça uma implementação concreta do método earnings na classe PieceWorker
 * que calcula os vencimentos do funcionário, multiplicando o número de peças
 * produzido pelo salário por peça. Crie um array de variáveis Employee para
 * armazenar referências a objetos de cada classe concreta na nova hierarquia
 * Employee. Para cada Employee, exiba sua representação de string e vencimentos.
 */

package ch10.Exer10_11;

public class Exer10_11 {

}
