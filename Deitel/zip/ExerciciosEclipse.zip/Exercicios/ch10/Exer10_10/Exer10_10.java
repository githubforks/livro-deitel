/*
 * (Hierarquia de formas)  Implemente a hierarquia Forma  mostrada na Figura 9.3.
 * Cada FormaBidimensional deve conter o método obterArea para calcular a área
 * da forma bidimensional. Cada FormaTridimensional deve ter métodos obterArea
 * e obterVolume para calcular a área do volume e a superfície, respectivamente,
 * da forma tridimensional. Crie um programa que utilize um array de referências
 * Forma para objetos de cada classe concreta na hierarquia. O programa deve
 * imprimir uma descrição de texto do objeto ao qual cada elementto no array se
 * refere. Além disso, no loop que processa todas as formas do array, determine
 * se cada forma é uma FormaBidimensional ou uma FormaTridimensional. Se uma
 * forma for uma FormaBidimensional, exiba sua área. Se uma forma for uma
 * FormaTridimensional, exiba sua área e volume.
 */

package ch10.Exer10_10;

public class Exer10_10 {

}
