/*
 * (Correspondência de arquivos com serialização de objetos) Recrie sua solução
 * para o Exercício 14.9 utilizando a serialização de objetos. Utilize as
 * instruções do Exercício 14.4 como sua base para esse programa. Talvez você
 * queira criar aplicativos para ler os dados armazenados nos arquivos .ser -
 * o código na seção 14.7.3 pode ser modificado para esse propósito.
 */

package ch14.Exer14_10;

public class Exer14_10 {

}
