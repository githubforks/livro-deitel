/*
 * (Pesquisa entre estudantes) A Figura 7.8 contém um array de respostas e uma
 * pesquisa que é codificada diretamente no programa. Suponha que queremos
 * processar os resultados dessa pesquisa que são armazenadosem um arquivo. Este
 * exercício requer dois programas separados. Primeiro, crie um aplicativo que
 * solicita ao usuário respostas à pesquisa e gera a saída de cada resposta para
 * cada um arquivo. Utilize um Formatter para criar um arquivo chamado
 * numbers.txt. Cada inteiro deve ser escrito com o método format. Então
 * midifique o programa na Figura 7.8 para ler as respostas à pesquisa a partir
 * de numbers.txt. As respostas devem ser lidas do arquivo utilizando Scanner. O
 * método nextInt deve ser utilizado para inserir um inteiro por vez a partir do
 * arquivo. O programa deve continuar a ler respostas até alcançar o fim do
 * arquivo. A saída dos resultados deve ser gravada no aruquivo de texto
 * "output.txt".
 */

package ch14.Exer14_13;

public class Exer14_13 {

}
